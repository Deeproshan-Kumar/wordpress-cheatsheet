<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php dispatch_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'dispatch' ); ?></a>
	<div class ="main-wrapper">
	<header id="masthead" class="site-header <?php echo (is_front_page())? 'homepage' : '';?>">
		<div class="container">
			<div class="header-content">
				<div class="site-branding">
					<div class="web-logo">
						<?php
							the_custom_logo();
						?>
					</div>
					<div class="mobile-logo">
						<div class="site-branding">
							<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link" rel="home" aria-current="page">
								<!-- <img class="white-logo" width="235" height="80" src="<?php 
								//echo get_template_directory_uri().'/public/images/logo.png'; ?>" class="custom-logo" alt="dispatch"> -->
								<img class="green-logo" width="170" height="auto" src="<?php echo get_template_directory_uri().'/public/images/logo.png'; ?>" class="custom-logo" alt="dispatch">
							</a>
						</div>
					</div>
				</div><!-- .site-branding -->

				<div class="header-rightbox">
					<nav id="site-navigation" class="main-navigation">
						<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false" id="openPrimary"><img class="menu" width="32" height="32" src="<?php echo get_template_directory_uri().'/public/images/menu.png'; ?>" class="custom-logo" alt="dispatch"></button>
						<div class="primary-menu">
							<div style="position:relative;height:100%" id="innner-toggle-menu">
								<!-- <button class="close-menu" id="closePrimary">x</button> -->

							<button class="close-menu" id="closePrimary">&times;</button>
							<div class="sub-primary">

								<?php
								wp_nav_menu(
									array(
										'menu' => 'header-menu', 
										'theme_location' => 'header-menu',
										'menu_id'        => 'primary-menu',
									)
								);
								?>
								<div class="header-btn-box">
									<a href="" class="reg-pg-link">Register</a>
									<a href="" class="login-pg-link">Login</a>
								</div>
							</div>
						</div>

					</nav>
				</div>
			</div>
		</div>
	</header>
	


						
					</nav>
					
				</div>
			</div>
		</div>
	</header><!-- #masthead -->

