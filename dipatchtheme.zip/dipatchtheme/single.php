<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post(); ?>
	<section class="news-detail-container">
		<div class="banner-image">
			<?php the_post_thumbnail('large'); ?>
		</div>

		<div class="information">
			<h2 class="published-date"><?php print the_date(); ?></h2>
			<h2 class="post-title"><?php the_title(); ?></h2>
			<div class="full-content"><?php the_content(); ?></div>
		</div>
	</section>
<?php
endwhile; // End of the loop.

get_footer();
