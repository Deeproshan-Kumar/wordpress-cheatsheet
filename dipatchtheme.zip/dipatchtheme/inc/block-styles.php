<?php
/**
 * Block Styles
 *
 * @link https://developer.wordpress.org/reference/functions/register_block_style/
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

if ( function_exists( 'register_block_style' ) ) {
	/**
	 * Register block styles.
	 *
	 * @since Dispatch
	 *
	 * @return void
	 */
	function dispatch_register_block_styles() {
		// Columns: Overlap.
		register_block_style(
			'core/columns',
			array(
				'name'  => 'dispatch-columns-overlap',
				'label' => esc_html__( 'Overlap', 'dispatch' ),
			)
		);

		// Cover: Borders.
		register_block_style(
			'core/cover',
			array(
				'name'  => 'dispatch-border',
				'label' => esc_html__( 'Borders', 'dispatch' ),
			)
		);

		// Group: Borders.
		register_block_style(
			'core/group',
			array(
				'name'  => 'dispatch-border',
				'label' => esc_html__( 'Borders', 'dispatch' ),
			)
		);

		// Image: Borders.
		register_block_style(
			'core/image',
			array(
				'name'  => 'dispatch-border',
				'label' => esc_html__( 'Borders', 'dispatch' ),
			)
		);

		// Image: Frame.
		register_block_style(
			'core/image',
			array(
				'name'  => 'dispatch-image-frame',
				'label' => esc_html__( 'Frame', 'dispatch' ),
			)
		);

		// Latest Posts: Dividers.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'dispatch-latest-posts-dividers',
				'label' => esc_html__( 'Dividers', 'dispatch' ),
			)
		);

		// Latest Posts: Borders.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'dispatch-latest-posts-borders',
				'label' => esc_html__( 'Borders', 'dispatch' ),
			)
		);

		// Media & Text: Borders.
		register_block_style(
			'core/media-text',
			array(
				'name'  => 'dispatch-border',
				'label' => esc_html__( 'Borders', 'dispatch' ),
			)
		);

		// Separator: Thick.
		register_block_style(
			'core/separator',
			array(
				'name'  => 'dispatch-separator-thick',
				'label' => esc_html__( 'Thick', 'dispatch' ),
			)
		);

		// Social icons: Dark gray color.
		register_block_style(
			'core/social-links',
			array(
				'name'  => 'dispatch-social-icons-color',
				'label' => esc_html__( 'Dark gray', 'dispatch' ),
			)
		);
	}
	add_action( 'init', 'dispatch_register_block_styles' );
}
