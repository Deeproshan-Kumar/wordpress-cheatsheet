<?php

if (!function_exists('dispatch_enqueue_main_styles')) :
    

    function dispatch_enqueue_main_styles() {

        wp_enqueue_style('dispatch-style', get_template_directory_uri() . '/public/css/custom.css', array(), _S_VERSION); 
  
    }
    add_action('wp_enqueue_scripts', 'dispatch_enqueue_main_styles', 30);
endif;

if (!function_exists('dispatch_enqueue_main_scripts')) :
    add_action('wp_enqueue_scripts', 'dispatch_enqueue_main_scripts');

    function dispatch_enqueue_main_scripts() {
        wp_enqueue_script("jquery");
        
        wp_enqueue_script('custom-js', get_template_directory_uri() . '/public/js/custom.js', array(), _S_VERSION, true);
      
    }

endif;
?>