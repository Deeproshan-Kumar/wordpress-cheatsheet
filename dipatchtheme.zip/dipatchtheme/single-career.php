<?php 

get_header(); ?>

<section class="career-single">
    <div class="career-detail-header">
        <h2><?php the_title(); ?></h2>
        <p><img src="<?php echo get_template_directory_uri(); ?>/public/images/Ellipse .png"><?php echo get_field('job_type'); ?> | <?php echo get_field('department'); ?></p>
    </div>

    <hr class="divider">
    
    <div class="career-detail-description">
        <a href="#job-application-form" class="apply-now-btn">Apply Now</a>
        <?php the_content(); ?>
    </div>
    <div class="job-application-form" id="job-application-form">
        <h4><?php the_title(); ?> Form</h4>
        <div class="career-application-form">
            <img src="<?php echo get_template_directory_uri() ?>/public/images/brand-logo.png" class="brand-logo">
            <p>Your Request Matters to Us!</p>
            <?php echo do_shortcode(' [contact-form-7 id="1012" title="Dispatch Career Application Form"] '); ?>
        </div>
    </div>
</section>

<?php get_footer(); ?>

