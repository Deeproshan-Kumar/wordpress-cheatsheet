<?php
/**
 * Displays the footer widget area.
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

if ( is_active_sidebar( 'sidebar-1' ) ) : ?>

	<footer>
		<div class="footer-box">
			<div class="footer-links">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>/faq/">FAQ</a>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>/buisness/">Businesss</a>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>/track-parcel/">Track Order</a>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>/delivery-agent/">Delivery Agent</a>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>/delivery-information/">Delivery Information</a>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>/about-us/">About Us</a>

				<div class="copyright-text">
					<p>© 2022 Dispatch Pte Ltd. All Rights Reserved.</p>
				</div>
			</div>
			<div class="social-links">
				<a href="">
					<img src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/uploads/2022/10/instagram.png" alt="" srcset="">
				</a>
				<a href="">
					<img src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/uploads/2022/10/tiktok.png" alt="" srcset="">
				</a>
				<a href="">
					<img src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/uploads/2022/10/fb.png" alt="" srcset="">
				</a>
				<a href="">
					<img src="<?php echo esc_url( home_url( '/' ) ); ?>/wp-content/uploads/2022/10/linkdin.png" alt="" srcset="">
				</a>
				<div class="f-links">
					<a href="http://dispatch.sg/">Home</a>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>/careers/">Career</a>
				<a href="<?php echo home_url() ?>/terms-and-condition">Terms & Conditions</a>
				</div>
			</div>
		</div>
	</footer>


<?php endif; ?>
