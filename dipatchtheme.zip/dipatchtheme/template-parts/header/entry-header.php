<?php
/**
 * Displays the post header
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

the_title( '<h1 class="entry-title">', '</h1>' );
