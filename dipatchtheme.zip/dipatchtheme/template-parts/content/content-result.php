<?php
/**
 * Template part for displaying post archives and search results
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="main-result">
		<?php if(has_post_thumbnail()) { ?>
		<div class="main-result-thumbanil">
	        <?php dispatch_post_thumbnail(); ?>
	    </div>
		<?php } ?>
		<div class="main-result-content">
			<?php
			// Don't show the title if the post-format is `aside` or `status`.
			$post_format = get_post_format();
			if (!( 'aside' === $post_format || 'status' === $post_format )) { ?>
				<header class="entry-header">
					<?php
					the_title( sprintf( '<h2 class="entry-title default-max-width"><a href="%s">', esc_url( get_permalink() ) ), '</a></h2>' );
					?>
				</header><!-- .entry-header -->	
			<?php } ?>
			<div class="entry-content">
				<?php get_template_part( 'template-parts/excerpt/excerpt', get_post_format() ); ?>
			</div><!-- .entry-content -->
			<footer class="entry-footer default-max-width">
				<?php dispatch_entry_meta_footer(); ?>
			</footer><!-- .entry-footer -->
		</div>
	</div>
</article><!-- #post-${ID} -->