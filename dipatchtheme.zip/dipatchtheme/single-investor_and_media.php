<?php 
/* 
    Template Name: Investor and Media Single
     Template Post Type:  page, investor_and_media
*/
get_header();
	while ( have_posts() ):
		the_post(); ?>
		<section class="investor-detail-container">
        <div class="banner-image">
			<?php the_post_thumbnail('large'); ?>
            <div class="tabs">
                <?php wp_nav_menu('banner-menu'); ?>
            </div>
		</div>
			<div class="information">
				<h2 class="published-date"><?php print the_date(); ?></h2>
				<h2 class="post-title"><?php the_title(); ?></h2>
                <b class="admin-name">by <?php bloginfo('admin_name'); ?></b>
				<div class="full-content"><?php the_content(); ?></div>
			</div>
		</section>
	<?php
	endwhile; // End of the loop.
	/* Start the Loop */
get_footer();
?>
