
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style type="text/css" href='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.6.0/sweetalert2.min.js'></style>
<div class="container">
  <form  id="submit_form" class="ds-forms">
    <div class="ds-form-box">
        <div class="ds-form-input" >
        <span class="span-label">Store Name<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Store Name" name="storeName">
        </div>
        <div class="ds-form-input">
        <span class="span-label">Contact Person’s Name<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Contact Person’s Name" name="contactPerson">
        </div>
        <div class="ds-form-input">
        <span class="span-label">Enter Email Address<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Enter Email Address*" name="contactEmail">
        </div>
        <div class="ds-form-input">
        <span class="span-label">Enter Phone Number<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Enter Phone Number*" name="contactNumber">
        </div>
        <div class="ds-form-input">
        <span class="span-label">Enter Comapny Name<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Enter Comapny Name*" name="companyName">
        </div>
        <div class="ds-form-input">
            <select id="industry" name='industryId'>
               
            </select>
        </div>
        <div class="ds-form-input">
        <span class="span-label">Enter Avg Monthly Volume<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Enter Avg Monthly Volume*" name="monthlyVolume">
        </div>
    </div>


    <div class="checkbox">
      <label><input type="checkbox" name="remember">By continuing, I confirm that I have read & agree to the <a href="http://dispatch.sg/terms-and-condition">terms of service</a> and <a href="">Privacy Policy</a></label>
    </div>
    <button type="button"  id='buisnessForm' class="btn btn-default submit-form-btn">Submit</button>
  </form>
</div>
<script>
$('#buisnessForm').on('click',function(e){
    var form = $('#submit_form')[0];

    var datas= new FormData(form);
    var object = {};
        datas.forEach(function(value, key){
        object[key] = value;
    });
    var json = JSON.stringify(object);

    $.ajax({
        url:"http://stgapi.dispatch.sg/web/business-expression",
        method:"POST",
        data:json,
        headers: {
            "Content-Type": "application/json"
        },
        success: function(resp){
            var res=JSON.parse(resp);

            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: res.message,
                showConfirmButton: false,
                timer: 1500
                })


    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
           var valid=JSON.parse(XMLHttpRequest.responseText);
           var field=valid.message;
            if(field.storeName){
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.storeName,

                    });

            }else if(field.contactPerson){

                  Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.contactPerson,

                    });
            }else if(field.contactEmail){

                 Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.contactEmail,

                    });
            }else if(field.contactNumber){


               Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.contactNumber,

                    });
            }else if(field.companyName){


               Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.companyName,

                    });
            }else if(field.monthlyVolume){

                Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.monthlyVolume,

                    });

            }else{
                Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',

                });
            }


        }
    });

});

$( document ).ready(function() {
     $.ajax({
        url:"http://stgapi.dispatch.sg/web/industry",
        method:"GET",
        beforeSend:function(){

        },
        success:function(data){
            var resp=JSON.parse(data);

            $.each(resp.data, function( index, value ) {
               $('#industry').append("<option value='"+value.id+"'>"+value.name+"</option>");
            });

        }
    });
});

</script>

