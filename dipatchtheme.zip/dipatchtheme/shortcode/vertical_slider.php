<body>
    <!--start-->
    <div class="vs-container">
        <div id="ninja-slider" style="float:left;">
            <div class="slider-inner">
                <ul>
                    <li><a class="ns-img" href="http://dispatch.sg/wp-content/uploads/2022/11/mobile.png" alt="loding..."></a></li>
                    <li><a class="ns-img" href="http://dispatch.sg/wp-content/uploads/2022/11/mobile.png" alt="loding..."></a></li>
                    <li><a class="ns-img" href="http://dispatch.sg/wp-content/uploads/2022/11/mobile.png" alt="loding..."></a></li>
                    <li><a class="ns-img" href="http://dispatch.sg/wp-content/uploads/2022/11/mobile.png" alt="loding..."></a></li>
                    
                </ul>
                <div class="fs-icon" title="Expand/Close"></div>
            </div>
        </div>
        <div id="thumbnail-slider" style="float:left;">
            <div class="inner">
                <ul>
                    <h2 class="heading-thumb">Easy Steps to Use the Service</h2>
                    <li>
                        <a class="thumb" href="http://dispatch.sg/wp-content/uploads/2022/11/Vector-6.png"></a>
                        <h3>Sign up</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Dui duis massa, sit vitae. Eu, nisi tincidunt id lorem nullam purus, nulla. </p>
                    </li>
                    <li>
                        <a class="thumb" href="http://dispatch.sg/wp-content/uploads/2022/11/Group-163082.png"></a>
                        <h3>Book a Delivery</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Dui duis massa, sit vitae. Eu, nisi tincidunt id lorem nullam purus, nulla. </p>
                    </li>
                    <li>
                        <a class="thumb" href="http://dispatch.sg/wp-content/uploads/2022/11/Group-163112.png"></a>
                        <h3>Match to an Agent</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Dui duis massa, sit vitae. Eu, nisi tincidunt id lorem nullam purus, nulla. </p>
                    </li>
                    <li>
                        <a class="thumb" href="http://dispatch.sg/wp-content/uploads/2022/11/location.png"></a>
                        <h3>Track your Order</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Dui duis massa, sit vitae. Eu, nisi tincidunt id lorem nullam purus, nulla. </p>
                    </li>
                    
                </ul>
            </div>
        </div>
        <div style="clear:both;"></div>
    </div>
</body>
