<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style type="text/css" href='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.6.0/sweetalert2.min.js'></style>
<div class="container">

  <form  id="submit_form" class="ds-forms">
    <div class="ds-form-box">
      <div class="ds-form-input">
        <span class="span-label">Full Name<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Full Name*" name="name">
      </div>
      <div class="ds-form-input">
      <span class="span-label">Mobile Number<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Mobile Number*" name="contactNumber">
      </div>
      <div class="ds-form-input">
      <span class="span-label">Email Address<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Email Address*" name="email">
      </div>
      <div class="ds-form-input">
      <span class="span-label">Subject<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Subject*" name="subject">
      </div>
      <div class="ds-form-input">
      <span class="span-label">Tracking ID<span style="color:red">*</span></span>
        <input type="text" class="form-control"  placeholder="Tracking ID*" name="trackingid">
      </div>
      <div class="ds-form-input">
        <label for="image" class="custom-file-label" id='image' name='image' value=''  >
        <input id="uploadFile" placeholder="Choose File*" class=""  id='upload_image' name='image' disabled />
            <div class="fileUpload btn btn-primary">
                <span>Upload Image</span>
                <input id="uploadBtn" type="file" class="upload" id='image' />
            </div>  
          <!-- <input type="file" class="form-control" id='image' placeholder="Enter Avg Monthly Volume"> -->
          <input type="hidden" class="form-control" id='upload_image' name='image' value='' placeholder="Upload Attachment">
        </label>
      </div>
      <div class="ds-form-input textarea-box">
      <span class="span-label">Type Message<span style="color:red">*</span></span>
        <textarea name="message" id="" cols="30" rows="7" placeholder="Type Message*"></textarea>
      </div>
      
    </div>
    <!-- <div class="checkbox">
      <label><input type="checkbox" name="remember"> Remember me</label>
    </div> -->
    <button type="button"  id='buisnessForm' class="md-btn submit-form-btn btn-default">Submit</button>
  </form>
</div>
<script>
$('#buisnessForm').on('click',function(e){
    var form = $('#submit_form')[0];

    var datas= new FormData(form);
    var object = {};
        datas.forEach(function(value, key){
        object[key] = value;
    });
    var json = JSON.stringify(object);

    $.ajax({
        url:"http://stgapi.dispatch.sg/web/contact-us",
        method:"POST",
        data:json,
        headers: {
            "Content-Type": "application/json"
        },
        success: function(resp){
            var res=JSON.parse(resp);

            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: res.message,
                showConfirmButton: false,
                timer: 1500
                })


    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
           var valid=JSON.parse(XMLHttpRequest.responseText);
           var field=valid.message;
            if(field.name){
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.name,

                    });

            }else if(field.email){

                  Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.email,

                    });
            }else if(field.contactNumber){

                  Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.contactNumber,

                    });
            }else if(field.subject){

                 Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.subject,

                    });
            }else if(field.message){


               Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: field.message,

                    });
            }else{
                Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',

                });
            }


        }
    });

});

$('#image').on('change',function(e){
  var form = new FormData();
form.append("image", this.files[0], "sdsadasdas.png");

    console.log(this.files[0]);
    $.ajax({
        url:"http://phpx8.singsys.net:3399/web/contact-us/image",
        method:"POST",
        data:form,
        cache : false,
        mimeType: "multipart/form-data",

        processData: false,
       contentType: false,

        success: function(resp){
         var resp=JSON.parse(resp);
          $('#upload_image').val(resp.data.url);
          // console.log();

    },
    error: function(XMLHttpRequest, textStatus, errorThrown) {
           var valid=JSON.parse(XMLHttpRequest.responseText);
           var field=valid.message;



        }
    });
});

</script>