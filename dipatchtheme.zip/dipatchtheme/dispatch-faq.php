<?php
/* 
Template Name: FAQs
*/
get_header();
?>

    <div class="faq-section">
        <div class="faq-header-contents">
        <div class="wrapper">
           <div class="inner">
                <h2>Frequently Asked Questions</h2>
                <p>Have questions? We are here to help</p>
           </div>
        </div>
            <div class="search-form">
                <input class="question-to-find" placeholder="Search your topic" required>
                <input type="submit" value="Search" class="search-btn">
            </div>
    </div>
    <div class="faq-tabs-section">
    <?php
        $args = array(
            'taxonomy' => 'faq_category',
            'orderby' => 'name',
            'order'   => 'ASC'
        );

        $cats = get_categories($args); ?>
        <ul class="tabs">
        <?php
            foreach($cats as $cat) :
        ?>
        <li class="cat-item" id="<?php echo $cat->term_id; ?>">
            <a href="<?php echo get_category_link( $cat->term_id ) ?>">
                <?php echo $cat->name; ?>
            </a>
        </li>
        <?php
        endforeach;
    ?>
    </ul>
</div>
<div class="filtered-question">
    <?php
        $args =  array(
            'post_type' => 'faq',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'order_by' => 'DESC',
        );
        
        ob_start();

        $allfaqs = new WP_Query($args);
        while( $allfaqs->have_posts() ) {
            $allfaqs->the_post(); ?>
            <details class="faq-accordian">
                <summary class="faq-content">
                    <h4><?php print the_title(); ?></h4>
                </summary>
                <?php the_content(); ?>
            </details>
        <?php	
        }
        
        $content = ob_get_clean();
        return $content;
        wp_reset_postdata();
    ?>
    </div>
    <?php the_content(); ?>
    <?php get_footer(); ?>