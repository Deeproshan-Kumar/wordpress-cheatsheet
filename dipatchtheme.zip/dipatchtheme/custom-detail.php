<?php
/**
 * Template Name: Detail Page
 * Template Post Type: post, page, projects, code
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post();
	?>
	<div class="dispatch-detail-page">
	<?php
	get_template_part( 'template-parts/content/content-post' );
	?>
	</div>
	<?php

endwhile; // End of the loop.

get_footer();
