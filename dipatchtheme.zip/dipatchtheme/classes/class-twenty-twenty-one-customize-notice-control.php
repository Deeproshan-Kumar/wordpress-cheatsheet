<?php
/**
 * Customize API: dispatch_Customize_Notice_Control class
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

/**
 * Customize Notice Control class.
 *
 * @since Dispatch
 *
 * @see WP_Customize_Control
 */
class dispatch_Customize_Notice_Control extends WP_Customize_Control {
	/**
	 * The control type.
	 *
	 * @since Dispatch
	 *
	 * @var string
	 */
	public $type = 'twenty-twenty-one-notice';

	/**
	 * Renders the control content.
	 *
	 * This simply prints the notice we need.
	 *
	 * @since Dispatch
	 *
	 * @return void
	 */
	public function render_content() {
		?>
		<div class="notice notice-warning">
			<p><?php esc_html_e( 'To access the Dark Mode settings, select a light background color.', 'dispatch' ); ?></p>
			<p><a href="<?php echo esc_url( __( 'https://wordpress.org/support/article/twenty-twenty-one/#dark-mode-support', 'dispatch' ) ); ?>">
				<?php esc_html_e( 'Learn more about Dark Mode.', 'dispatch' ); ?>
			</a></p>
		</div>
		<?php
	}
}
