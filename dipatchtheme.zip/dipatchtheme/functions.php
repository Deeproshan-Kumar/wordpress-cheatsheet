<?php
/**
 * Functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Dispatch
 * @since Dispatch
 */

// This theme requires WordPress 5.3 or later.
if ( version_compare( $GLOBALS['wp_version'], '5.3', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

if ( ! function_exists( 'dispatch_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * @since Dispatch
	 *
	 * @return void
	 */
	function dispatch_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on dispatch, use a find and replace
		 * to change 'dispatch' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'dispatch', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * This theme does not use a hard-coded <title> tag in the document head,
		 * WordPress will provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/**
		 * Add post-formats support.
		 */
		add_theme_support(
			'post-formats',
			array(
				'link',
				'aside',
				'gallery',
				'image',
				'quote',
				'status',
				'video',
				'audio',
				'chat',
			)
		);

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1568, 9999 );

		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'dispatch' ),
				'banner' => esc_html__( 'banner menu 2', 'dispatch' ),
				'banner2' => esc_html__( 'banner menu 3', 'dispatch' ),
				'banner3' => esc_html__( 'banner menu 4', 'dispatch' ),
				'footer'  => esc_html__( 'Secondary menu', 'dispatch' )
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		/*
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		$logo_width  = 300;
		$logo_height = 100;

		add_theme_support(
			'custom-logo',
			array(
				'height'               => $logo_height,
				'width'                => $logo_width,
				'flex-width'           => true,
				'flex-height'          => true,
				'unlink-homepage-logo' => true,
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		// Add support for editor styles.
		add_theme_support( 'editor-styles' );
		$background_color = get_theme_mod( 'background_color', 'D1E4DD' );
		if ( 127 > dispatch_Custom_Colors::get_relative_luminance_from_hex( $background_color ) ) {
			add_theme_support( 'dark-editor-style' );
		}

		$editor_stylesheet_path = './assets/css/style-editor.css';

		// Note, the is_IE global variable is defined by WordPress and is used
		// to detect if the current browser is internet explorer.
		global $is_IE;
		if ( $is_IE ) {
			$editor_stylesheet_path = './assets/css/ie-editor.css';
		}

		// Enqueue editor styles.
		add_editor_style( $editor_stylesheet_path );

		// Add custom editor font sizes.
		add_theme_support(
			'editor-font-sizes',
			array(
				array(
					'name'      => esc_html__( 'Extra small', 'dispatch' ),
					'shortName' => esc_html_x( 'XS', 'Font size', 'dispatch' ),
					'size'      => 16,
					'slug'      => 'extra-small',
				),
				array(
					'name'      => esc_html__( 'Small', 'dispatch' ),
					'shortName' => esc_html_x( 'S', 'Font size', 'dispatch' ),
					'size'      => 18,
					'slug'      => 'small',
				),
				array(
					'name'      => esc_html__( 'Normal', 'dispatch' ),
					'shortName' => esc_html_x( 'M', 'Font size', 'dispatch' ),
					'size'      => 20,
					'slug'      => 'normal',
				),
				array(
					'name'      => esc_html__( 'Large', 'dispatch' ),
					'shortName' => esc_html_x( 'L', 'Font size', 'dispatch' ),
					'size'      => 24,
					'slug'      => 'large',
				),
				array(
					'name'      => esc_html__( 'Extra large', 'dispatch' ),
					'shortName' => esc_html_x( 'XL', 'Font size', 'dispatch' ),
					'size'      => 40,
					'slug'      => 'extra-large',
				),
				array(
					'name'      => esc_html__( 'Huge', 'dispatch' ),
					'shortName' => esc_html_x( 'XXL', 'Font size', 'dispatch' ),
					'size'      => 96,
					'slug'      => 'huge',
				),
				array(
					'name'      => esc_html__( 'Gigantic', 'dispatch' ),
					'shortName' => esc_html_x( 'XXXL', 'Font size', 'dispatch' ),
					'size'      => 144,
					'slug'      => 'gigantic',
				),
			)
		);

		// Custom background color.
		add_theme_support(
			'custom-background',
			array(
				'default-color' => 'd1e4dd',
			)
		);

		// Editor color palette.
		$black     = '#000000';
		$dark_gray = '#28303D';
		$gray      = '#39414D';
		$green     = '#D1E4DD';
		$blue      = '#D1DFE4';
		$purple    = '#D1D1E4';
		$red       = '#E4D1D1';
		$orange    = '#E4DAD1';
		$yellow    = '#EEEADD';
		$white     = '#FFFFFF';

		add_theme_support(
			'editor-color-palette',
			array(
				array(
					'name'  => esc_html__( 'Black', 'dispatch' ),
					'slug'  => 'black',
					'color' => $black,
				),
				array(
					'name'  => esc_html__( 'Dark gray', 'dispatch' ),
					'slug'  => 'dark-gray',
					'color' => $dark_gray,
				),
				array(
					'name'  => esc_html__( 'Gray', 'dispatch' ),
					'slug'  => 'gray',
					'color' => $gray,
				),
				array(
					'name'  => esc_html__( 'Green', 'dispatch' ),
					'slug'  => 'green',
					'color' => $green,
				),
				array(
					'name'  => esc_html__( 'Blue', 'dispatch' ),
					'slug'  => 'blue',
					'color' => $blue,
				),
				array(
					'name'  => esc_html__( 'Purple', 'dispatch' ),
					'slug'  => 'purple',
					'color' => $purple,
				),
				array(
					'name'  => esc_html__( 'Red', 'dispatch' ),
					'slug'  => 'red',
					'color' => $red,
				),
				array(
					'name'  => esc_html__( 'Orange', 'dispatch' ),
					'slug'  => 'orange',
					'color' => $orange,
				),
				array(
					'name'  => esc_html__( 'Yellow', 'dispatch' ),
					'slug'  => 'yellow',
					'color' => $yellow,
				),
				array(
					'name'  => esc_html__( 'White', 'dispatch' ),
					'slug'  => 'white',
					'color' => $white,
				),
			)
		);

		add_theme_support(
			'editor-gradient-presets',
			array(
				array(
					'name'     => esc_html__( 'Purple to yellow', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'purple-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to purple', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $purple . ' 100%)',
					'slug'     => 'yellow-to-purple',
				),
				array(
					'name'     => esc_html__( 'Green to yellow', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $green . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'green-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to green', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $green . ' 100%)',
					'slug'     => 'yellow-to-green',
				),
				array(
					'name'     => esc_html__( 'Red to yellow', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'red-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to red', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $red . ' 100%)',
					'slug'     => 'yellow-to-red',
				),
				array(
					'name'     => esc_html__( 'Purple to red', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $red . ' 100%)',
					'slug'     => 'purple-to-red',
				),
				array(
					'name'     => esc_html__( 'Red to purple', 'dispatch' ),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $purple . ' 100%)',
					'slug'     => 'red-to-purple',
				),
			)
		);

		/*
		* Adds starter content to highlight the theme on fresh sites.
		* This is done conditionally to avoid loading the starter content on every
		* page load, as it is a one-off operation only needed once in the customizer.
		*/
		if ( is_customize_preview() ) {
			require get_template_directory() . '/inc/starter-content.php';
			add_theme_support( 'starter-content', dispatch_get_starter_content() );
		}

		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );

		// Add support for custom line height controls.
		add_theme_support( 'custom-line-height' );

		// Add support for experimental link color control.
		add_theme_support( 'experimental-link-color' );

		// Add support for experimental cover block spacing.
		add_theme_support( 'custom-spacing' );

		// Add support for custom units.
		// This was removed in WordPress 5.6 but is still required to properly support WP 5.5.
		add_theme_support( 'custom-units' );

		// Remove feed icon link from legacy RSS widget.
		add_filter( 'rss_widget_feed_link', '__return_false' );
	}
}
add_action( 'after_setup_theme', 'dispatch_setup' );

/**
 * Register widget area.
 *
 * @since Dispatch
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 *
 * @return void
 */
function dispatch_widgets_init() {

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer', 'dispatch' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here to appear in your footer.', 'dispatch' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', 'dispatch_widgets_init' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @since Dispatch
 *
 * @global int $content_width Content width.
 *
 * @return void
 */
function dispatch_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'dispatch_content_width', 750 );
}
add_action( 'after_setup_theme', 'dispatch_content_width', 0 );
add_action( 'after_setup_theme', 'register_my_menu' );
function register_my_menu() {
  register_nav_menu( 'footer_menu', __( 'Footer Menu', 'dispatch' ) );
  register_nav_menu( 'contact_menu', __( 'Contact Menu', 'dispatch' ) );
  register_nav_menu( 'social_menu', __( 'Social Menu', 'dispatch' ) );
}

/**
 * Enqueue scripts and styles.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_scripts() {
	// Note, the is_IE global variable is defined by WordPress and is used
	// to detect if the current browser is internet explorer.
	global $is_IE, $wp_scripts;
	if ( $is_IE ) {
		// If IE 11 or below, use a flattened stylesheet with static values replacing CSS Variables.
		wp_enqueue_style( 'twenty-twenty-one-style', get_template_directory_uri() . '/assets/css/ie.css', array(), wp_get_theme()->get( 'Version' ) );
	} else {
		// If not IE, use the standard stylesheet.
		wp_enqueue_style( 'twenty-twenty-one-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get( 'Version' ) );
	}
	wp_enqueue_style( 'response-style', get_template_directory_uri() . '/public/css/responsive.css', array(), wp_get_theme()->get( 'Version' ) );

	// RTL styles.
	wp_style_add_data( 'twenty-twenty-one-style', 'rtl', 'replace' );

	// Print styles.
	wp_enqueue_style( 'twenty-twenty-one-print-style', get_template_directory_uri() . '/assets/css/print.css', array(), wp_get_theme()->get( 'Version' ), 'print' );

	// Threaded comment reply styles.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Register the IE11 polyfill file.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills-asset',
		get_template_directory_uri() . '/assets/js/polyfills.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

	// Register the IE11 polyfill loader.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills',
		null,
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
	wp_add_inline_script(
		'twenty-twenty-one-ie11-polyfills',
		wp_get_script_polyfill(
			$wp_scripts,
			array(
				'Element.prototype.matches && Element.prototype.closest && window.NodeList && NodeList.prototype.forEach' => 'twenty-twenty-one-ie11-polyfills-asset',
			)
		)
	);

	// Main navigation scripts.
	if ( has_nav_menu( 'primary' ) ) {
		wp_enqueue_script(
			'twenty-twenty-one-primary-navigation-script',
			get_template_directory_uri() . '/assets/js/primary-navigation.js',
			array( 'twenty-twenty-one-ie11-polyfills' ),
			wp_get_theme()->get( 'Version' ),
			true
		);
	}

	// Responsive embeds script.
	wp_enqueue_script(
		'twenty-twenty-one-responsive-embeds-script',
		get_template_directory_uri() . '/assets/js/responsive-embeds.js',
		array( 'twenty-twenty-one-ie11-polyfills' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'dispatch_scripts' );

/**
 * Enqueue block editor script.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_block_editor_script() {

	wp_enqueue_script( 'dispatch-editor', get_theme_file_uri( '/assets/js/editor.js' ), array( 'wp-blocks', 'wp-dom' ), wp_get_theme()->get( 'Version' ), true );
}

add_action( 'enqueue_block_editor_assets', 'dispatch_block_editor_script' );

// slider js

/**
 * Fix skip link focus in IE11.
 *
 * This does not enqueue the script because it is tiny and because it is only for IE11,
 * thus it does not warrant having an entire dedicated blocking script being loaded.
 *
 * @since Dispatch
 *
 * @link https://git.io/vWdr2
 */
function dispatch_skip_link_focus_fix() {

	// If SCRIPT_DEBUG is defined and true, print the unminified file.
	if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
		echo '<script>';
		include get_template_directory() . '/assets/js/skip-link-focus-fix.js';
		echo '</script>';
	} else {
		// The following is minified via `npx terser --compress --mangle -- assets/js/skip-link-focus-fix.js`.
		?>
		<script>
		/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",(function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())}),!1);
		</script>
		<?php
	}
}
add_action( 'wp_print_footer_scripts', 'dispatch_skip_link_focus_fix' );

/**
 * Enqueue non-latin language styles.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_non_latin_languages() {
	$custom_css = dispatch_get_non_latin_css( 'front-end' );

	if ( $custom_css ) {
		wp_add_inline_style( 'twenty-twenty-one-style', $custom_css );
	}
}
add_action( 'wp_enqueue_scripts', 'dispatch_non_latin_languages' );

// SVG Icons class.
require get_template_directory() . '/classes/class-twenty-twenty-one-svg-icons.php';

// Custom color classes.
require get_template_directory() . '/classes/class-twenty-twenty-one-custom-colors.php';
new dispatch_Custom_Colors();

// Enhance the theme by hooking into WordPress.
require get_template_directory() . '/inc/template-functions.php';

// Menu functions and filters.
require get_template_directory() . '/inc/menu-functions.php';

// Custom template tags for the theme.
require get_template_directory() . '/inc/template-tags.php';

// Customizer additions.
require get_template_directory() . '/classes/class-twenty-twenty-one-customize.php';
new dispatch_Customize();

// Block Patterns.
require get_template_directory() . '/inc/block-patterns.php';

// Block Styles.
require get_template_directory() . '/inc/block-styles.php';

// Dark Mode.
require_once get_template_directory() . '/classes/class-twenty-twenty-one-dark-mode.php';
new dispatch_Dark_Mode();

/**
 * Enqueue scripts for the customizer preview.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_customize_preview_init() {
	wp_enqueue_script(
		'dispatch-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

	wp_enqueue_script(
		'dispatch-customize-preview',
		get_theme_file_uri( '/assets/js/customize-preview.js' ),
		array( 'customize-preview', 'customize-selective-refresh', 'jquery', 'dispatch-customize-helpers' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'customize_preview_init', 'dispatch_customize_preview_init' );

/**
 * Enqueue scripts for the customizer.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_customize_controls_enqueue_scripts() {

	wp_enqueue_script(
		'dispatch-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'customize_controls_enqueue_scripts', 'dispatch_customize_controls_enqueue_scripts' );

/**
 * Calculate classes for the main <html> element.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_the_html_classes() {
	/**
	 * Filters the classes for the main <html> element.
	 *
	 * @since Dispatch
	 *
	 * @param string The list of classes. Default empty string.
	 */
	$classes = apply_filters( 'dispatch_html_classes', '' );
	if ( ! $classes ) {
		return;
	}
	echo 'class="' . esc_attr( $classes ) . '"';
}

/**
 * Add "is-IE" class to body if the user is on Internet Explorer.
 *
 * @since Dispatch
 *
 * @return void
 */
function dispatch_add_ie_class() {
	?>
	<script>
	if ( -1 !== navigator.userAgent.indexOf( 'MSIE' ) || -1 !== navigator.appVersion.indexOf( 'Trident/' ) ) {
		document.body.classList.add( 'is-IE' );
	}
	</script>
	<?php
}
add_action( 'wp_footer', 'dispatch_add_ie_class' );

/**
 * Go Truck helper functions
 */
require get_theme_file_path('inc/custom-script-style.php');


/**
 * Custom Pagination
 */

function custom_paginate_links( $args = '' ) {
	global $wp_query, $wp_rewrite;

	// Setting up default values based on the current URL.
	$pagenum_link = html_entity_decode( get_pagenum_link() );
	$url_parts    = explode( '?', $pagenum_link );

	// Get max pages and current page out of the current query, if available.
	$total   = isset( $wp_query->max_num_pages ) ? $wp_query->max_num_pages : 1;
	$current = get_query_var( 'paged' ) ? (int) get_query_var( 'paged' ) : 1;

	// Append the format placeholder to the base URL.
	$pagenum_link = trailingslashit( $url_parts[0] ) . '%_%';

	// URL base depends on permalink settings.
	$format  = $wp_rewrite->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
	$format .= $wp_rewrite->using_permalinks() ? user_trailingslashit( $wp_rewrite->pagination_base . '/%#%', 'paged' ) : '?paged=%#%';

	$defaults = array(
		'base'               => $pagenum_link, // http://example.com/all_posts.php%_% : %_% is replaced by format (below).
		'format'             => $format, // ?page=%#% : %#% is replaced by the page number.
		'total'              => $total,
		'current'            => $current,
		'aria_current'       => 'page',
		'show_all'           => false,
		'prev_next'          => true,
		'prev_text'          => __( '&laquo; Previous' ),
		'next_text'          => __( 'Next &raquo;' ),
		'end_size'           => 1,
		'mid_size'           => 2,
		'type'               => 'plain',
		'add_args'           => array(), // Array of query args to add.
		'add_fragment'       => '',
		'before_page_number' => '',
		'after_page_number'  => '',
	);

	$args = wp_parse_args( $args, $defaults );

	if ( ! is_array( $args['add_args'] ) ) {
		$args['add_args'] = array();
	}

	// Merge additional query vars found in the original URL into 'add_args' array.
	if ( isset( $url_parts[1] ) ) {
		// Find the format argument.
		$format       = explode( '?', str_replace( '%_%', $args['format'], $args['base'] ) );
		$format_query = isset( $format[1] ) ? $format[1] : '';
		wp_parse_str( $format_query, $format_args );

		// Find the query args of the requested URL.
		wp_parse_str( $url_parts[1], $url_query_args );

		// Remove the format argument from the array of query arguments, to avoid overwriting custom format.
		foreach ( $format_args as $format_arg => $format_arg_value ) {
			unset( $url_query_args[ $format_arg ] );
		}

		$args['add_args'] = array_merge( $args['add_args'], urlencode_deep( $url_query_args ) );
	}

	// Who knows what else people pass in $args.
	$total = (int) $args['total'];
	if ( $total < 2 ) {
		return;
	}
	$current  = (int) $args['current'];
	$end_size = (int) $args['end_size']; // Out of bounds? Make it the default.
	if ( $end_size < 1 ) {
		$end_size = 1;
	}
	$mid_size = (int) $args['mid_size'];
	if ( $mid_size < 0 ) {
		$mid_size = 2;
	}

	$add_args   = $args['add_args'];
	$r          = '';
	$page_links = array();
	$dots       = false;

	if ( $args['prev_next'] && $current && 1 < $current ) :
		$link = str_replace( '%_%', 2 == $current ? '' : $args['format'], $args['base'] );
		$link = str_replace( '%#%', $current - 1, $link );
		if ( $add_args ) {
			$link = add_query_arg( $add_args, $link );
		}
		$link .= $args['add_fragment'];

		$page_links[] = sprintf(
			'<a class="prev page-numbers" href="%s">%s</a>',
			/**
			 * Filters the paginated links for the given archive pages.
			 *
			 * @since 3.0.0
			 *
			 * @param string $link The paginated link URL.
			 */
			esc_url( apply_filters( 'paginate_links', $link ) ),
			$args['prev_text']
		);
	endif;

	for ( $n = 1; $n <= $total; $n++ ) :
		if ( $n == $current ) :
			$page_links[] = sprintf(
				'<span aria-current="%s" class="page-numbers current">%02s</span>',
				esc_attr( $args['aria_current'] ),
				$args['before_page_number'] . number_format_i18n( $n ) . $args['after_page_number']
			);

			$dots = true;
		else :
			if ( $args['show_all'] || ( $n <= $end_size || ( $current && $n >= $current - $mid_size && $n <= $current + $mid_size ) || $n > $total - $end_size ) ) :
				$link = str_replace( '%_%', 1 == $n ? '' : $args['format'], $args['base'] );
				$link = str_replace( '%#%', $n, $link );
				if ( $add_args ) {
					$link = add_query_arg( $add_args, $link );
				}
				$link .= $args['add_fragment'];

				$page_links[] = sprintf(
					'<a class="page-numbers" href="%s">%02s</a>',
					/** This filter is documented in wp-includes/general-template.php */
					esc_url( apply_filters( 'paginate_links', $link ) ),
					$args['before_page_number'] . number_format_i18n( $n ) . $args['after_page_number']
				);

				$dots = true;
			elseif ( $dots && ! $args['show_all'] ) :
				$page_links[] = '<span class="page-numbers dots">' . __( '&hellip;' ) . '</span>';

				$dots = false;
			endif;
		endif;
	endfor;

	if ( $args['prev_next'] && $current && $current < $total ) :
		$link = str_replace( '%_%', $args['format'], $args['base'] );
		$link = str_replace( '%#%', $current + 1, $link );
		if ( $add_args ) {
			$link = add_query_arg( $add_args, $link );
		}
		$link .= $args['add_fragment'];

		$page_links[] = sprintf(
			'<a class="next page-numbers" href="%s">%s</a>',
			/** This filter is documented in wp-includes/general-template.php */
			esc_url( apply_filters( 'paginate_links', $link ) ),
			$args['next_text']
		);
	endif;

	switch ( $args['type'] ) {
		case 'array':
			return $page_links;

		case 'list':
			$r .= "<ul class='page-numbers'>\n\t<li>";
			$r .= implode( "</li>\n\t<li>", $page_links );
			$r .= "</li>\n</ul>\n";
			break;

		default:
			$r = implode( "\n", $page_links );
			break;
	}

	/**
	 * Filters the HTML output of paginated links for archives.
	 *
	 * @since 5.7.0
	 *
	 * @param string $r    HTML output.
	 * @param array  $args An array of arguments. See paginate_links()
	 *                     for information on accepted arguments.
	 */
	$r = apply_filters( 'paginate_links_output', $r, $args );

	return $r;
}


function country_taxonomies() {
	$country_method = array(
		'name' => _x( 'Countries', 'taxonomy general name' ),
	    'singular_name' => _x( 'Country', 'taxonomy singular name' ),
	    'search_items' =>  __( 'Search Countries' ),
	    'all_items' => __( 'All Countries' ),
	    'parent_item' => __( 'Parent Country' ),
	    'parent_item_colon' => __( 'Parent Country:' ),
	    'edit_item' => __( 'Edit Country' ), 
	    'update_item' => __( 'Update Country' ),
	    'add_new_item' => __( 'Add New Country' ),
	    'new_item_name' => __( 'New Country Name' ),
	    'menu_name' => __( 'Countries' ),
	);
	$args = array(
		'hierarchical' => true,
		'labels' => $country_method,
		'show_ui' => true,
		'show_in_rest' => true,
    	'show_admin_column' => true,
		'query_var' => true,
		'rewrite' => array( 'slug' => 'country' )
	);
    register_taxonomy( 'country', array( 'post' ), $args );
}
add_action( 'init', 'country_taxonomies', 0 );

/**
 * News and Events
 */
function wpb_news_shortcode($atts) {
	$category = 'news';

	$postperpage = (isset($atts['post-per-page']) && $atts['post-per-page']) ? $atts['post-per-page'] : -1;

	$orientation = (isset( $atts['show-in'] ) && $atts['show-in']) ? $atts['show-in'] : 'list';

	$pagination = (isset( $atts['pagination'] ) && $atts['pagination']) ? $atts['pagination'] : 'true';

	$btn = (isset( $atts['btn'] ) && $atts['btn']) ? $atts['btn'] : 'true';

	$args = array(  
        'post_type' => 'post',
        'post_status' => 'publish',
        'category_name' => $category,
        'posts_per_page' => $postperpage,
        'orderby' => 'date',
        'order' => 'DESC',
        'paged' => get_query_var('paged') ? get_query_var('paged') : 1
    );
	ob_start();
    $loop = new WP_Query( $args ); ?>
    <div class="wp-nepost">
    	<div class="wp-nepost-container allnews">
    		<div class="wp-nepost-row <?php echo $orientation; ?>">
		    	<?php
		    	if($loop->have_posts()) {
			    	while ( $loop->have_posts() ) : $loop->the_post(); 
			    	$post = get_post($loop);
			    	$blocks = parse_blocks($post->post_content);
			        if($orientation == 'list') { ?>
			        <div class="wp-nepost-grid <?php echo $category;?>" id="post-<?php the_ID(); ?>">
			        	<div class="wp-nepost-grid-card">
			        		<?php if(has_post_thumbnail()) { ?>
								<div class="wp-nepost-thumbnail">
									<img src="<?php echo get_the_post_thumbnail_url( null, 'full' ) ?>" />
								</div>
							<?php } ?>
							<div class="wp-nepost-content-wrapper">
								<div class="wp-nepost-meta-date">
					        		<?php echo get_the_date( get_option( 'M j, Y' ) ); ?>
					        	</div>
					        	<div class="wp-nepost-entry-title">
					        		<a href="<?php echo get_the_permalink(); ?>" class="title-link"><?php echo get_the_title(); ?></a>
					        	</div>
					        	<div class="wp-nepost-entry-content">
					        		<?php 
					        			echo get_the_excerpt(); 
					        		?>
					        	</div>
					        	<?php if($btn == 'true' && $category == 'news') {?>
					        	<div class="wp-nepost-entry-button">
					        		<a class="know-more-btn" href="<?php echo get_the_permalink(); ?>">Know More</a>
					        	</div>
					        	<?php }?>
					        </div>
					    </div>
			        </div>
		        <?php } else if($orientation == 'grid') { ?>
		        	<div class="wp-nepost-grid <?php echo $category;?>" id="post-<?php the_ID(); ?>">
			        	<div class="wp-nepost-grid-card">
			        		<?php if(has_post_thumbnail()) { ?>
								<div class="wp-nepost-thumbnail">
									<img src="<?php echo get_the_post_thumbnail_url( null, 'full' ) ?>" />
								</div>
							<?php } ?>
							<div class="wp-nepost-content-wrapper">
					        	<div class="wp-nepost-entry-title">
					        		<a href="<?php echo get_the_permalink(); ?>" class="title-link"><?php echo get_the_title(); ?></a>
					        	</div>
								<div class="wp-nepost-meta-date">
					        		<?php echo get_the_date( get_option( 'M j, Y' ) ); ?>
					        	</div>
					        	<?php if($btn == 'true' && $category == 'news') {?>
					        	<div class="wp-nepost-entry-button">
					        		<a class="know-more-btn" href="<?php echo get_the_permalink(); ?>">Know More</a>
					        	</div>
					        	<?php }?>
					        </div>
					    </div>
			        </div>
		        <?php } 
		    	endwhile; } else { ?>
		        	<div style="font-size: 16px;line-height: 22px;text-align: center;font-family: 'Product Sans', sans-serif;margin: 30px auto;">Nothing to show here. Thankyou</div>
		        <?php } ?>
    		</div>
		</div>
	   	<?php if($pagination == 'true') { ?>
	    	<div class="premium-nepost-pagination-container">
		    <?php
			    $big = 999999999; // need an unlikely integer
				$paginate_links = custom_paginate_links( array(
				    'base' 		=> str_replace( $big, '%#%', get_pagenum_link( $big ) ),
				    'format' 	=> '?paged=%#%',
				    'current' 	=> max( 1, get_query_var('paged') ),
				    'total' 	=> $loop->max_num_pages,
				    'prev_next' => true,
				    'prev_text' => __('Previous'),
			        'next_text' => __('Next'),
			        'type' 		=> 'array'
				));
				if($paginate_links)
					foreach ( $paginate_links as $link ) {
				        echo sprintf("%02s", $link);
				    }
		    ?>
			</div>
		<?php } ?>
    </div>
    <script>
	    jQuery(".wp-nepost-entry-content a.more-link").remove();
	</script>
	<?php
	$content = ob_get_clean();
    wp_reset_postdata(); 
    return $content;
?>
<?php } 
	add_shortcode('news', 'wpb_news_shortcode');

function wpb_event_shortcode($atts) {
	$category = 'upcoming-event';

	$postperpage = -1;

	$args = array(  
        'post_type' => 'post',
        'post_status' => 'publish',
        'category_name' => $category,
        'posts_per_page' => $postperpage,
        'orderby' => 'date',
        'order' => 'ASC',
        'paged' => get_query_var('paged') ? get_query_var('paged') : 1
    );

	ob_start();
    $loop = new WP_Query( $args ); ?>
    <div class="wp-nepost">
    	<div class="wp-nepost-container">
    		<div class="wp-nepost-row">
		    	<?php
		        	if($loop->have_posts()) {
			    	while ( $loop->have_posts() ) : $loop->the_post(); 
			    	$post = get_post($loop);
			    	$blocks = parse_blocks($post->post_content);
			    	$starttime = get_field('start_date_and_time');
			    	$endtime = get_field('end_date_and_time');
			        ?>
			        <div class="wp-nepost-grid <?php echo $category;?>" id="post-<?php the_ID(); ?>">
			        	<div class="wp-nepost-grid-card">
							<div class="wp-nepost-content-wrapper">
								<div class="wp-nepost-meta-country">
					        		<?php
    									$countries = implode(', ',wp_get_post_terms(get_the_id(), 'country', array('fields' => 'names') ));
    									echo $countries;
    								?>
					        	</div>
					        	<div class="wp-nepost-entry-title">
					        		<?php echo get_the_title(); ?>
					        	</div>
								<div class="wp-nepost-meta-date">
					        		<?php 
					        		$st = DateTime::createFromFormat('M j, Y H:i', $starttime);
					        		$en = DateTime::createFromFormat('M j, Y H:i', $endtime);
					        		if($st->format('Y') === $en->format('Y')){
					        			if($st->format('M') === $en->format('M')){
					        				if($st->format('j') === $en->format('j')){
					        					echo $en->format('j M Y')." | ".$st->format('H:i')." onwards";
					        				} else {
					        					echo $st->format('j')." - ".$en->format('j M Y')." | ".$st->format('H:i')." onwards";
					        				}
					        			} else{
					        				echo $st->format('j M')." - ".$en->format('j M Y')." | ".$st->format('H:i')." onwards";
					        			}
					        		} else {
					        			echo $st->format('j M Y')." - ".$en->format('j M Y')." | ".$st->format('H:i')." onwards";
					        		}
					        		?>
					        	</div>
					        	<div class="wp-nepost-entry-content">
					        		<?php 
					        			echo get_the_excerpt(); 
					        		?>
					        	</div>
					        </div>
					    </div>
			        </div>
		        <?php endwhile; }
		        else{ ?>
		        	<div style="font-size: 16px;line-height: 22px;text-align: center;font-family: 'Product Sans', sans-serif;margin: 30px auto;">Nothing to show here. Thankyou</div>
		        <?php } ?>
    		</div>
		</div>
    </div>
    <script>
	    jQuery(".wp-nepost-entry-content a.more-link").remove();
	</script>
	<?php
	$content = ob_get_clean();
    wp_reset_postdata(); 
    return $content;
?>
<?php } 
	add_shortcode('event', 'wpb_event_shortcode');


// Investor and Media CPT 
	function investor_and_media() {
	
	$labels = array(
		'name' => _x( 'Investors and Media', 'post type general name' ),
		'singular_name' => _x( 'Investor and Media', 'post type singular name' ),
		'add_new' => _x( 'Add New', 'Investor' ),
		'add_new_item' => __( 'Add New Investor' ),
		'edit_item' => __( 'Edit Investor and Media' ),
		'new_item' => __( 'New Investor and Media' ),
		'all_items' => __( 'All Investors and Media' ),
		'view_item' => __( 'View Investors and Media' ),
		'search_items' => __( 'Search Investors and Media' ),
		'not_found' => __( 'No Investors and Media found' ),
		'not_found_in_trash' => __( 'No Investors and Media found in the Trash' ),
		'parent_item_colon' => '',
		'supports'        => array('title', 'page-attributes','thumbnail'), // Page Attributes Support
		'menu_name' => 'Investors and Media'
	);
	
	// args array
	
	$args = array(
		'labels' => $labels,
		'description' => 'Displays Investors and Media',
		'public' => true,
		'menu_position' => 4,
		'supports' => array( 'title', 'editor', 'excerpt', 'thumbnail'),
		'has_archive' => true,
		'rewrite' => array('slug' => 'investor-and-media', 'with_front' => false),
	);
	
	register_post_type( 'investor_and_media', $args );
}

add_action( 'init', 'investor_and_media' );

// Custom Taxonomy for Investor and Media

function investor_and_media_taxonomies() {

	// labels array
	
	$labels = array(
		'name' => _x( 'Investors and Media Categories', 'taxonomy general name' ),
		'singular_name' => _x( 'Investors and Media', 'taxonomy singular name' ),
		'search_items' => __( 'Search Investors and Media Categories' ),
		'all_items' => __( 'All Investors and Media Categories' ),
		'parent_item' => __( 'Parent Investors and Media Category' ),
		'parent_item_colon' => __( 'Parent Investors and Media Category:' ),
		'edit_item' => __( 'Edit Investors and Media Category' ),
		'update_item' => __( 'Update Investors and Media Category' ),
		'add_new_item' => __( 'Add New Investors and Media Category' ),
		'new_item_name' => __( 'New Investors and Media Category' ),
		'menu_name' => __( ' Investors and Media Categories' ),
	);
	
	// args array
	
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	
	register_taxonomy( 'investor_and_media_taxonomies', 'investor_and_media', $args );
	}
	
	add_action( 'init', 'investor_and_media_taxonomies', 0 );



	// Display CPT Investor and Media

	function cpt_investor_and_media($atts) {
		$atts = shortcode_atts(
			array(
				'post_type' => 'investor_and_media',
				'post_status' => 'publish',
				'posts_per_page' => 4,
				'orderby' => 'date',
				'order' => 'ASC',
				'pagination' => 'true'
			), $atts
		);
		$investor_args = array(
				'post_type' => $atts['post_type'],
				'post_status' => $atts['post_status'],
				'posts_per_page' => $atts['posts_per_page'],
				'orderby' => $atts['orderby'],
				'order' => $atts['order'],
				'paged' => (get_query_var('paged')) ? get_query_var('paged') : 1
		);

		ob_start();

		$loop = new WP_Query($investor_args);?>
		<div class="card-box">
		<?php while($loop->have_posts()): 
			$loop->the_post(); ?>
			<a href="<?php the_permalink(); ?>">
				<article class="investor-card">
				<div class="thumbnail">
					<div class="thumbnail-image">
						<?php the_post_thumbnail(); ?>
						<p><?php echo get_the_date("M d, Y"); echo " at " .get_the_time(); ?></p>
					</div>
				</div>
				<div class="card-body">
					<div class="card-body-contents">
						<h2 class="post-title"><?php print the_title(); ?></h2> 
						<p class="admin-name"><?php echo "by "; bloginfo('admin_name');?></p>
						<p class="post-except"><?php the_excerpt(); ?>
					</div>
				</div>
			</article>
		</a>
		<?php
		endwhile;?>
		</div>
		<div class="pagination-wrapper">
		<?php if ($atts['pagination'] === 'true') {
			$big = 999999999; // need an unlikely integer
			 echo paginate_links( array(
			    'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
			    'format' => '?paged=%#%',
			    'current' => max( 1, get_query_var('paged') ),
			    'total' => $loop->max_num_pages,
			    'prev_next' => false
			) );
		}?>
		</div>
		<?php $content = ob_get_clean();
    wp_reset_postdata(); 
    return $content;
	}

	add_shortcode('investor_and_media', 'cpt_investor_and_media');

// Feature News Post Information
function featured_posts_info($atts) {
$atts = shortcode_atts(
		array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => 3,
			'orderby' => 'date',
			'order' => 'ASC',
			'pagination' => 'true'
		), $atts
	);

$featured_posts_args = array(
	'post_type' => $atts['post_type'],
	'post_status' => $atts['post_status'],
	'posts_per_page' => $atts['posts_per_page'],
	'orderby' => $atts['orderby'],
	'order' => $atts['order'],
);

ob_start(); 

$featured_posts = new WP_Query($featured_posts_args);?>
<div class="news-cardbox">
<?php while($featured_posts->have_posts()):
	$featured_posts->the_post(); ?>

	<article class="featured-post-card">
		<div class="featured-post-thumbnail">
			<div class="featured-image">
				<?php the_post_thumbnail(); ?>
				<p><?php echo get_the_date("M d Y"); ?></p>
			</div>
		</div>
		<div class="featured-card-body">
			<h2><?php print the_title(); ?></h2>
			<p class="featured-excerpt">
				<?php echo get_the_excerpt(); ?>
			</p>
			<a href="<?php the_permalink(); ?>">Read More</a>
		</div>
	</article>
<?php
endwhile; ?>
</div>
<div class="pagination-wrapper">
		<?php if ($atts['pagination'] === 'true') {
			$big = 999999999; // need an unlikely integer
			 echo paginate_links( array(
			    'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
			    'format' => '?paged=%#%',
			    'current' => max( 1, get_query_var('paged') ),
			    'total' => $featured_posts->max_num_pages,
			    'prev_next' => false
			) );
		}?>
</div>
<?php $content = ob_get_clean();
wp_reset_postdata();
return $content;
}

add_shortcode('featured_posts', 'featured_posts_info');

// 

function wpc_elementor_shortcode( $atts ) {
    // echo "This is my custom PHP output in Elementor!";
	ob_start();
	include(ABSPATH.'/wp-content/themes/dipatchtheme/shortcode/contact_us.php');
	return ob_get_clean();
}
add_shortcode( 'my_elementor_php_output', 'wpc_elementor_shortcode');

function wpc_elementor_shortcode_buisness( $atts ) {
    // echo "This is my custom PHP output in Elementor!";
	ob_start();
	include(ABSPATH.'/wp-content/themes/dipatchtheme/shortcode/request_buisness_users.php');
	return ob_get_clean();
}
add_shortcode( 'bussness_php_output', 'wpc_elementor_shortcode_buisness');
// vertical slider

function wpc_elementor_shortcode_slider( $atts ) {
    // echo "This is my custom PHP output in Elementor!";
	ob_start();
	include(ABSPATH.'/wp-content/themes/dipatchtheme/shortcode/vertical_slider.php');
	return ob_get_clean();
}
add_shortcode( 'slider_php_output', 'wpc_elementor_shortcode_slider');


// buisness user form

function include_file($atts) {
    $a = shortcode_atts( array(
        'slug' => 'NULL',
    ), $atts );

    if($slug != 'NULL'){
        ob_start();
        get_template_part($a['slug']);
        return ob_get_clean();
    }
}
add_shortcode('include', 'include_file');


if(!function_exists( 'my_theme_scripts' ) ) :
	function my_theme_scripts () {

		wp_enqueue_script( 'slider-js', get_template_directory_uri() . '/assets/js/jssor.slider-28.1.0.min.js', array(), wp_get_theme()->get('Version'), false );
		wp_script_add_data( 'slider-js', 'async', true );
	}
	endif;
	add_action( 'wp_enqueue_scripts', 'my_theme_scripts' );


// - Deeproshan Kumar 
###### Career Page Custom Post Type ###### 

if( !function_exists(' dispatch_careers ') ) :
function dispatch_careers() {

	// labels array added inside the function and precedes args array

	$labels = array(
		'name' => _x( 'Careers', 'post type general name' ),
		'singular_name' => _x( 'Career', 'post type singular name' ),
		'add_new' => _x( 'Add New', 'Job' ),
		'add_new_item' => __( 'Add New Job' ),
		'edit_item' => __( 'Edit Job' ),
		'new_item' => __( 'New Job' ),
		'all_items' => __( 'All Jobs' ),
		'view_item' => __( 'View Job' ),
		'search_items' => __( 'Search Jobs' ),
		'not_found' => __( 'No jobs found' ),
		'not_found_in_trash' => __( 'No jobs found in the Trash' ),
		'parent_item_colon' => '',
		'supports'        => array('title', 'page-attributes','thumbnail'), 
		'menu_name' => 'Careers',
	);
	
	// args array
	
	$args = array(
		'labels' => $labels,
		'description' => 'Displays jobs for various profile',
		'public' => true,
		'menu_position' => 4,
		'menu_icon'=>'dashicons-portfolio',
		'supports' => array( 'title', 'editor', 'thumbnail'),
		'has_archive' => true,
		'rewrite' => array('slug' => 'career', 'with_front' => false),
	);
	
	register_post_type( 'career', $args );
}
endif;
add_action( 'init', 'dispatch_careers' );

// Custom Taxonomy for Careers

if( !function_exists(' dispatch_careers_taxonomies ') ) :
function dispatch_careers_taxonomies() {

	// labels array
	
	$labels = array(
		'name' => _x( 'Job Categories', 'taxonomy general name' ),
		'singular_name' => _x( 'Job Category', 'taxonomy singular name' ),
		'search_items' => __( 'Search Categories' ),
		'all_items' => __( 'All Categories' ),
		'parent_item' => __( 'Parent Category' ),
		'parent_item_colon' => __( 'Parent Category:' ),
		'edit_item' => __( 'Edit Category' ),
		'update_item' => __( 'Update Category' ),
		'add_new_item' => __( 'Add New Category' ),
		'new_item_name' => __( 'New Category' ),
		'menu_name' => __( ' Job Categories' ),
	);
	
	// args array
	
	$args = array(
		'labels' => $labels,
		'hierarchical' => true,
	);
	
	register_taxonomy( 'career_category', 'career', $args );
	}
	endif;
	add_action( 'init', 'dispatch_careers_taxonomies', 0 );

###### Displaying Careers ######

if( !function_exists(' dispatch_careers_shortcode ') ) :
function dispatch_careers_shortcode(){ // Shortcode registration
	$terms = get_terms( array(
		'taxonomy' => 'career_category',
		'hide_empty' => false,
		'parent' => 0 // Getting all parent category
	));

	ob_start();

	?>
	<div class="career-filter-wrapper">
		<?php 
			foreach($terms as $term):
				$child_terms = get_terms( array(
				'taxonomy' => 'career_category',
				'hide_empty' => false,
				'parent' => $term->term_id, // Getting id of parent category
			)); 
		?>
		<div class="cards-container">
			<select class="filter-items">
				<option value="<?php echo $term->name; ?>" selected disabled><?php echo $term->name; ?></option>
				<!-- Getting Parent Category -->
				<?php foreach($child_terms as $child_term): ?>
					<option value="<?php echo $child_term->term_id; ?>" id="<?php echo $child_term->term_id; ?>" class="filter-item" data-id = "<?php echo $child_term->term_id; ?>"><?php echo $child_term->name; ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<?php endforeach; ?>
		<button class="reset-filter">Reset <img src="<?php echo get_template_directory_uri(); ?>/public/images/reset-icon.png"></button>
	</div>
	
	<?php 
	$content = ob_get_clean();
		wp_reset_postdata(); 
	return $content;
	}
endif;
add_shortcode('filter_dispatch_careers', 'dispatch_careers_shortcode'); // Shortcode

###### AJAX hoos for Career page #####

add_action('wp_ajax_nopriv_filterCareers', 'filterCareers_ajax');
add_action('wp_ajax_filterCareers', 'filterCareers_ajax');

###### Required Scripts ######

if( !function_exists(' my_enqueue ') ) :
function my_enqueue() {
	wp_enqueue_script( 'career-script', get_template_directory_uri().'/public/js/career.js', array('jquery') );
	// FAQ page script 
	wp_enqueue_script( 'faq-script', get_template_directory_uri().'/public/js/faq.js', array('jquery') );
}
endif;
add_action( 'wp_enqueue_scripts', 'my_enqueue' );

######  Getting Filter Results ###### 

	if( !function_exists(' filterCareers_ajax ') ) :
	function filterCareers_ajax(){
		$args =  array(
			'post_type' => 'career',
			'post_status' => 'publish',
			'posts_per_page' => -1, 
			'order_by' => 'DESC',
		);
	
		// tax_query
		
		$cat_id = $_POST['cat_id'];
	
		if(count($cat_id) !== 0){
			$args['tax_query'] ['relation']= 'AND';
			foreach ($cat_id as $catid) {
				$args['tax_query'] []= array(
					'taxonomy' => 'career_category',
					'field'    => 'id',
					'terms'    => $catid,
				);
			}
		}
	
		$loop = new WP_Query($args); 
	
		if($loop->have_posts()): ?>
			<div class="search-res-container">
			<?php	
			while ( $loop->have_posts() ) : $loop->the_post(); ?>
			<div class="career filtered-career">
				<div class="filtered-career-inner">
					<div class="table-cell title-and-type">
						<h4 class="job-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
						<p><img src="<?php echo get_template_directory_uri(); ?>/public/images/Ellipse .png"><?php echo get_field('job_type'); ?></p>
					</div>
					<div class="table-cell department">
						<p><?php echo get_field('department'); ?></p>
					</div>
					<div class="table-cell location">
						<p><?php echo get_field('location'); ?></p>
					</div>
					<div class="table-cell apply">
						<a href="<?php the_permalink(); ?>" class="dispatch-btn">Apply</a>
					</div>
				</div>
			</div>
			<?php endwhile; ?>
	</div>
	<?php
	else: 
		echo  "<div class='no-jobs-found'>
		<p>No Jobs Found !</p>
		</div>
		";
	endif;
		wp_reset_postdata(); 
		die();
	}
endif;

######   Function to display all Careers   ###### 

if( !function_exists(' allCareers ') ) :
	function allCareers(){
		$args =  array(
			'post_type' => 'career',
			'post_status' => 'publish',
			'posts_per_page' => -1, 
			'order_by' => 'DESC',
		);

		ob_start();

		$loop = new WP_Query($args); 
	
		if($loop->have_posts()): ?>
			<div class="search-res-container">
			<?php	
			while ( $loop->have_posts() ) : $loop->the_post(); ?>
				<div class="career filtered-career">
					<div class="filtered-career-inner">
						<div class="table-cell title-and-type">
							<h4 class="job-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
							<p><img src="<?php echo get_template_directory_uri(); ?>/public/images/Ellipse .png"><?php echo get_field('job_type'); ?></p>
						</div>
						<div class="table-cell department">
							<p><?php echo get_field('department'); ?></p>
						</div>
						<div class="table-cell location">
							<p><?php echo get_field('location'); ?></p>
						</div>
						<div class="table-cell apply">
							<a href="<?php the_permalink(); ?>" class="dispatch-btn">Apply</a>
						</div>
					</div>
				</div>
			<?php endwhile; ?>
			</div>
	<?php
		$content = ob_get_clean();
		wp_reset_postdata(); 
		return $content;
	endif;
	}
endif;
add_shortcode('dispatch_all_careers', 'allCareers'); // Shortcode


######  Custom Post Type FAQ's  ###### 

if( !function_exists(' dispatch_faq ') ) :
	function dispatch_faq() {
		// labels array added inside the function and precedes args array
		$labels = array(
			'name' => _x( 'FAQ', 'post type general name' ),
			'singular_name' => _x( 'FAQ', 'post type singular name' ),
			'add_new' => _x( 'Add New', 'Question' ),
			'add_new_item' => __( 'Add Question' ),
			'edit_item' => __( 'Edit Question' ),
			'new_item' => __( 'New Question' ),
			'all_items' => __( 'All Questions' ),
			'view_item' => __( 'View Question' ),
			'search_items' => __( 'Search Questions' ),
			'not_found' => __( 'No Questions found' ),
			'not_found_in_trash' => __( 'No Questions found in the Trash' ),
			'parent_item_colon' => '',
			'supports'        => array('title', 'page-attributes','thumbnail'), 
			'menu_name' => 'FAQs',
		);
		
		// args array
		
		$args = array(
			'labels' => $labels,
			'description' => 'FAQ',
			'public' => true,
			'menu_position' => 5,
			'supports' => array( 'title', 'editor', 'thumbnail'),
			'has_archive' => true,
			'rewrite' => array('slug' => 'faq', 'with_front' => false),
		);
		
		register_post_type( 'faq', $args );
	}
endif;
add_action( 'init', 'dispatch_faq' );

######  Custom Taxonomy for FAQ  ###### 
if( !function_exists(' dispatch_faq_taxonomies ') ) :
	function dispatch_faq_taxonomies() {
		// labels array
		$labels = array(
			'name' => _x( 'Categories', 'taxonomy general name' ),
			'singular_name' => _x( 'Category', 'taxonomy singular name' ),
			'search_items' => __( 'Search Categories' ),
			'all_items' => __( 'All Categories' ),
			'parent_item' => __( 'Parent Category' ),
			'parent_item_colon' => __( 'Parent Category:' ),
			'edit_item' => __( 'Edit Category' ),
			'update_item' => __( 'Update Category' ),
			'add_new_item' => __( 'Add New Category' ),
			'new_item_name' => __( 'New Category' ),
			'menu_name' => __( 'Categories' ),
		);
		
		// args array
		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
		);
		register_taxonomy( 'faq_category', 'faq', $args );
	}
endif;
add_action( 'init', 'dispatch_faq_taxonomies');

// FAQ Page Specific  Scripts 
if( !function_exists( 'my_enqueue_faq' ) ) :
function my_enqueue_faq() {
	wp_enqueue_script( 'ajax-script', get_template_directory_uri().'/public/js/faq.js',
		array('jquery') );
	wp_localize_script( 'ajax-script', 'my_ajax_object',
		array( 'ajax_url' => admin_url( 'admin-ajax.php')) );
}
endif;
add_action( 'wp_enqueue_scripts', 'my_enqueue_faq');

// Hooks for FAQs Search functionality
add_action( 'wp_ajax_nopriv_searchFaqs', 'searchFaqs' );
add_action( 'wp_ajax_searchFaqs', 'searchFaqs' );
function searchFaqs(){
	$keyword = $_POST['keyword'];
	$args =  array(
		'post_type' => 'faq',
		'post_status' => 'publish',
		'posts_per_page' => -1,
		'order_by' => 'DESC',
		's' => $keyword,
	);

	$searchres = new WP_Query($args); 
	if( $searchres->have_posts() && !empty( $args['s'] )): ?>
		<div class="search-res-container">
			<?php	
				while ( $searchres->have_posts() ) : 
					$searchres->the_post();
				?>
					<details class="faq-accordian">
						<summary class="faq-content">
							<h4><?php print the_title(); ?></h4>
						</summary>
						<?php the_content(); ?>
					</details>
				<?php
				endwhile; 
				?>
		</div> 
	<?php
	else :
		echo "<div class='error-msg'><p>Question not found...!</p></div>";
	endif;
	wp_reset_postdata(); 
	die();
}

######  FAQ Tabs Functionality ###### 

// Hooks to Filter FAQs
add_action( 'wp_ajax_nopriv_filterFaqs', 'filterFaqs' );
add_action( 'wp_ajax_filterFaqs', 'filterFaqs' );
function filterFaqs(){
	$category_id = $_POST['category'];
	$args =  array(
		'post_type' => 'faq',
		'post_status' => 'publish',
		'posts_per_page' => -1, 
		'order_by' => 'DESC',
		'tax_query' => array( // tax_query
			array(
				'taxonomy' => 'faq_category', 
				'field'    => 'id',
				'terms'    => $category_id,
			),
		),
	);

	$faqs = new WP_Query( $args );

	if( $faqs->have_posts() ) :
		while( $faqs->have_posts() ) :
			$faqs->the_post(); ?>
			<details class="faq-accordian">
				<summary class="faq-content">
					<h4><?php print the_title(); ?></h4>
				</summary>
				<?php the_content(); ?>
			</details>
		<?php 
		endwhile;
	endif;
	wp_reset_postdata();
	die();
}

// Shortcode for FAQs 

function faq_shortcode() { 
	ob_start();  
	?>
	<div class="faq-section">
	<div class="faq-header-contents">
	<div class="wrapper">
	   <div class="inner">
			<h2>Frequently Asked Questions</h2>
			<p>Have questions? We are here to help</p>
	   </div>
	</div>
		<div class="search-form">
			<input class="question-to-find" placeholder="Search your topic" required>
			<input type="submit" value="Search" class="search-btn">
		</div>
</div>

<div class="filtered-question">
<?php
$args =  array(
	'post_type' => 'faq',
	'post_status' => 'publish',
	'posts_per_page' => -1,
	'order_by' => 'DESC',
);

$allfaqs = new WP_Query($args);



if( $allfaqs->have_posts() ) :
while( $allfaqs->have_posts() ) :
	$allfaqs->the_post(); ?>
	<details class="faq-accordian">
		<summary class="faq-content">
			<h4><?php print the_title(); ?></h4>
		</summary>
		<?php the_content(); ?>
	</details>
<?php	
endwhile;
wp_reset_postdata();
$content = ob_get_clean();
return $content;
endif;

?>
</div>
<?php
}
add_shortcode( 'faqs_shortcode', 'faq_shortcode' );

// js integration

if( !function_exists(' my_enqueues ') ) :
	function my_enqueues() {
		wp_enqueue_script( 'slider-script', get_template_directory_uri() . '/public/js/ninja-slider.js', array('jquery') );
		// FAQ page script 
		wp_enqueue_script( 'thumb-script', get_template_directory_uri() . '/public/js/thumbnail-slider.js', array('jquery') );
	}
endif;
add_action( 'wp_enqueue_scripts', 'my_enqueues' );

