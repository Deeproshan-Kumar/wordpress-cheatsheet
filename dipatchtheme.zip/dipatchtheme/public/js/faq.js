function getTitleOfQuestion() {
    let questionToFind = document.querySelector(".question-to-find").value;
    return questionToFind;
}

// FAQ Search Functionality
jQuery(document).on('click', '.search-btn', function(e){
    e.preventDefault();
    var keyword = getTitleOfQuestion(); // Getting value of input field.
    // console.log(keyword);
    jQuery.ajax({
        type: 'post',
        dataType: 'html',
        url: my_ajax_object.ajax_url,
        data : { action: "searchFaqs", keyword: keyword }, 
        success: function(res){
            jQuery('.filtered-question').html(res);
        },
        error: function(res){
            console.log(res);
        }
    });
});

// FAQ Tabs Functionality
jQuery(function(){
    jQuery('.cat-item').on('click', function(e) {
        e.preventDefault();
        jQuery('.cat-item').removeClass('active');
        jQuery(this).addClass('active');
        var category = jQuery(this).attr('id'); // Getting value of id attribute from <li>.
        // console.log(category);
        jQuery.ajax({
            type: 'post',
            dataType: 'html',
            url: my_ajax_object.ajax_url,
            data: { action: "filterFaqs", category: category },
            success: function(res) {
                jQuery('.filtered-question').html(res);
            },
            error: function(res){
                console.log(res);
            }
        });
    });
});
