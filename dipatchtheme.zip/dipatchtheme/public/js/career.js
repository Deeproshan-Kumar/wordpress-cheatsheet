// Getting Selected Items of Drop Down

function  getSelectedCatIds (){
    var selectedOptionsIds = [];
    jQuery("select.filter-items").each(function(){
        var value = jQuery(this).val();
        if(jQuery.trim(value)){
            selectedOptionsIds.push(value);
        }
    });
    return selectedOptionsIds;
}

jQuery(document).on('change', '.cards-container .filter-items', function(e){
    e.preventDefault();
    jQuery('.reset-filter').removeClass("active");
    var cat_id = getSelectedCatIds();
    // console.log(cat_id);
    jQuery.ajax({
        type: 'post',
        dataType: 'html',
        url: my_ajax_object.ajax_url,
        data : {action: "filterCareers", 'cat_id' : cat_id },
        success: function(res){
            jQuery('.search-results .search-res-container').html(res);
        },
        error: function(res){
            // console.log(res);
        }
    });
});


jQuery(document).on('click', '.reset-filter', function(){
    jQuery(this).toggleClass("active");
    jQuery.ajax({
        type: 'post',
        dataType: 'html',
        url: my_ajax_object.ajax_url,
        data : {action: "filterCareers" },
        success: function(res){
            jQuery('.search-results .search-res-container').html(res);
        },
        error: function(res){
            // console.log(res);
        }
    });
});
