jQuery('.resume input[type="file"]').on('change', function(e){
	var fileName = e.target.files[0].name;
	jQuery('.file-info').text(fileName);
});

jQuery('.search-button').on('click', function(){
jQuery(' + .search-form-popup',this).toggleClass('search_popup-show');
});

jQuery(function(){
	jQuery(document).on('click', '#openPrimary', function(){
		console.log('hahaha');
		jQuery('body').addClass('menu-open');
	});
	jQuery(document).on('click', '#closePrimary', function(){
		jQuery('body').removeClass('menu-open');
	});
});


(function($){
	$(document).on('ready', function(){
		$('[data-elementor-type="wp-page"],.news-detail-container,.investor-detail-container').css({
			'min-height': 'calc(100vh - '+($('.footer-box').innerHeight() + $('.site-header').innerHeight() + 32)+'px)'
		});
	});
	$(window).on('resize orientationchange', function(){
		$('[data-elementor-type="wp-page"],.news-detail-container,.investor-detail-container').css({
			'min-height': 'calc(100vh - '+($('.footer-box').innerHeight() + $('.site-header').innerHeight() + 32)+'px)'
		});
	});
}(jQuery));

(function($) {
    $(window).on("scroll", function() {
        if($(window).scrollTop() > 80) {
            $("header").addClass("active");
        } else {
           $("header").removeClass("active");
        }
    });
}(jQuery));

// Modified
let uploadBtn = document.getElementById("uploadBtn");
if(uploadBtn) {
	uploadBtn.addEventListener('change', function(){
		let file =  document.getElementById("uploadFile");
		file.value = this.value;
	})
}

// document.getElementById("uploadBtn").onchange = function () {
//     document.getElementById("uploadFile").value = this.value;
// };

jQuery(document).ready(function($) {
var delay = 100; setTimeout(function() {
$('.elementor-tab-title').removeClass('elementor-active');
 $('.elementor-tab-content').css('display', 'none'); }, delay);
});


// Career Form Script 
window.onload = function() {
	let radios = document.querySelectorAll('#residency input[type="radio"]');
	let select = document.querySelector('select[name="country"]');
	select.style.display="none";
	radios.forEach(radio=>{
		radio.addEventListener('change', function(){
			if(radio.getAttribute("value") === "No") {
				console.log("Works")
				select.style.display="block";
			} else{
				select.style.display="none";
			}
		});
	})
}