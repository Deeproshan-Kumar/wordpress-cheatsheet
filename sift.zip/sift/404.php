<?php

get_header();

get_template_part( 'template-parts/content', 'error' ); 

get_footer();

?>