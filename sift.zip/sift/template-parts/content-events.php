<?php
// Event Template
    $currentDateTime = date( 'd F Y' );
    $startDate = get_field( 'start_date' );
    $currentDate = strtotime( $currentDateTime );
    $dateToCompare = strtotime( $startDate );
?>

<div class="event">
    <article class="card">
        <div class="thumbnail">
            <?php 
            if( has_post_thumbnail() ) :
                the_post_thumbnail();
            else: ?>
            <img src="<?php echo get_template_directory_uri() ?>/public/images/brand-logo.png" alt="">
            <?php   
            endif;
            ?>
        </div>
        <div <?php echo ( $currentDate >= $dateToCompare ) ? "class='event-details past-event-details'" : "class='event-details'"; ?>>
            <h4><?php print the_title(); ?></h4>
            <div class="date-and-time">
                <div class="date">
                    <div class="wrapper">
                        <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_calendar.svg" alt="" class="icon">
                        <div class="start-and-end-date">
                            <?php 
                            if( get_field( 'end_date' ) ) :
                                $time = strtotime( get_field( 'start_date' ) );
                                echo '<span class="day">' . ltrim( date( 'd', $time ), "0" ) . '</span>-'. get_field( 'end_date' );
                            else :
                                echo get_field( 'start_date' );
                            endif; ?>
                        </div>
                    </div>
                </div>

                <?php if( get_field( 'end_time' ) || get_field( 'start_time' ) ) : ?>
                <div class="time">
                    <div class="wrapper">
                            <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_time .svg" alt="" class="icon">
                            <div class="start-and-end-time">
                                <?php 
                                if( get_field( 'end_time' ) ) :
                                    $start_time = get_field( 'start_time' );
                                    echo '<span class="time">' . date( "H:i", strtotime( $start_time ) ) . '</span>-'.get_field( 'end_time' ); 
                                else :
                                    echo get_field( 'start_time' ); 
                                endif; ?>
                            </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="location">
                <span class="icon"><img src="<?php echo get_template_directory_uri() ?>/public/images/sift_location .svg" alt=""></span>
                <span class="info"><?php echo get_field( 'location' ); ?></span>
            </div>

            <div class="actions buttons">
                <div class="wrapper">
                <?php if( get_field( 'event_detail_page_url' ) ) : 
                    $btn = get_field('url_open_method'); 
                    if( $btn && in_array('New Window', $btn ) ) : ?>
                        <a href="<?php echo get_field( 'event_detail_page_url' ); ?>" class="button" target="_blank">Details</a>
                    <?php else: ?>
                        <a href="<?php echo get_field( 'event_detail_page_url' ); ?>" class="button">Details</a>
                    <?php endif; ?>
                   
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" class="facebook-link" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/public/images/sift_facebook.svg">
                        <p>Share</p>
                    </a>

                <?php elseif( get_field( 'registration_link' ) ) : 
                    $btn = get_field('url_open_method'); 
                    if( $btn && in_array('New Window', $btn ) ) : ?>
                        <a href="<?php echo get_field( 'registration_link' ); ?>" class="button" target="_blank">Register</a>
                    <?php else: ?>
                        <a href="<?php echo get_field( 'registration_link' ); ?>" class="button">Register</a>
                    <?php endif; ?>

                     <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" class="facebook-link" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/public/images/sift_facebook.svg">
                        <p>Share</p>
                    </a>
                <?php else : ?>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </article>
</div>