<?php
// Template Story Single Post 
?>

<article <?php post_class();?>>
    <div class="post-thumbnail">
        <?php the_post_thumbnail(); ?>
    </div>
    <h3 class="post-title"><?php the_title(); ?></h3>
    <div class="date-and-author">
        <p>Published on : <span><?php echo get_the_date(); ?></span></p>
        <p>By : <span><?php the_author(); ?></span></p>
    </div>
    <?php the_content(); ?>
</article>