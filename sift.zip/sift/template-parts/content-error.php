<?php
// Error Page Template
if ( ! defined( 'ABSPATH' ) ) :
	exit; // Exit if accessed directly.
endif;
?>

<article class="main-content">
    <div class="wrapper">
        <ul>
            <li>4</li>
            <li>0</li>
            <li>4</li>
        </ul>
        <p>Go back to home page <a href="<?php echo home_url(); ?>">Click here</a></p>
    </div>
</article>
