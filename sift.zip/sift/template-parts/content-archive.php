<?php
// Archive Template
?>

<?php the_content(); ?>

