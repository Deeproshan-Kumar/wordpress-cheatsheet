<?php
// Template Single Event 
?>

<article <?php post_class(); ?>>
    <div class="card">
        <div class="thumbnail">
            <?php 
            if( has_post_thumbnail() ) :
                the_post_thumbnail();
            else: ?>
            <img src="<?php echo get_template_directory_uri() ?>/public/images/brand-logo.png" alt="" class="icon">
            <?php   
            endif;
            ?>
        </div>
        <div class="event-details">
            <h4><?php print the_title(); ?></h4>
            <div class="date-and-time">
                <div class="date">
                    <div class="wrapper">
                        <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_calendar.svg" alt="" class="icon">
                        <div class="start-and-end-date">
                            <?php 
                            if( get_field( 'end_date' ) ) :
                                $time = strtotime( get_field( 'start_date' ) );
                                echo '<span class="day">' . date( 'd', $time ) . '</span>-'. get_field( 'end_date' );
                            else :
                                echo get_field( 'start_date' ); 
                            endif; ?>
                        </div>
                    </div>
                </div>

                <div class="time">
                    <div class="wrapper">
                        <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_time .svg" alt="" class="icon">
                        <div class="start-and-end-time">
                            <?php 
                            if( get_field( 'start_time' ) ) :
                                $last_date = get_lastpostdate();
                                echo '<span class="time">' . date( "H:i", strtotime( $last_date ) ) . '</span>-'.get_field( 'end_time' ); 
                            else :
                                echo get_field( 'start_time' ); 
                            endif; ?>
                        </div>
                    </div>
                </div>
            </div>    
            
            <div class="location">
                <span class="icon"><img src="<?php echo get_template_directory_uri() ?>/public/images/sift_location .svg" alt=""></span>
                <span class="info"><?php echo get_field( 'location' ); ?></span>
            </div>
            
            <?php the_content(); ?>
        </div>
    </div>
</article>