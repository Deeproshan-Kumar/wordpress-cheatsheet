<?php
// Template Single Post 
?>

<?php the_content(); ?>
