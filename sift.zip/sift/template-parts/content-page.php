<?php
// Page Template
?>
<article class="main-content">
<?php the_content(); ?>
</article>
