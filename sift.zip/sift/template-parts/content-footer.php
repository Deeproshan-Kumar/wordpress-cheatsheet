<?php 
// Footer template 
function currentYear(){
    return date('Y');
}
?>

<div class="sift_footer_inner">
    <section class="footer widget_1">
        <?php dynamic_sidebar( 'first-footer-widget-area' ); ?>   
    </section>
    <section class="footer widget_2">
        <?php dynamic_sidebar( 'second-footer-widget-area' ); ?>   
    </section>
    <section class="footer widget_3">
        <?php dynamic_sidebar( 'third-footer-widget-area' ); ?>   
    </section>
    <section class="footer widget_4">
        <?php dynamic_sidebar( 'fourth-footer-widget-area' ); ?>   
    </section>
    <section class="footer widget_5">
        <?php dynamic_sidebar( 'fifth-footer-widget-area' ); ?>   
    </section>
    <div class="bottom-to-top">
        <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/public/images/sift_bottom_to_top.png"></a>
    </div>
</div>