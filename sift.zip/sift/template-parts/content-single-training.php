<?php
// Template Training Detail 
$startDate = get_field( 'start_date' );
$startDateOfTraining = strtotime( $startDate );
$endDate = get_field( 'start_date' );
$endDateOfTraining = strtotime( $startDate );
?>

<section class="training-info">
    <div class="training-title">
        <h2>
            <?php print the_title(); ?>
            <?php 
            if( get_field( 'training_code' ) ) : 
                echo "<span class='training-id'>" . get_field( 'training_code' ) . "</span>";
            endif;
            ?>
        </h2>
    </div>
    <div class="wrapper">
            <h2 class="price duration">Course Fee -&nbsp;
                <span class="price">
                    <?php echo get_field( 'price' ); ?>
                </span>
                <span class="course-duration">
                    Course duration: <?php echo str_replace( "-"," ",strtolower( get_field( 'training_duration' ) ) ); ?>
                </span>
            </h2>
            <div class="date-and-time">
                <div class="date">
                    <div class="group">
                        <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_calendar.svg" alt=""
                            class="icon">
                        <div class="start-and-end-date">
                            <?php
                            if ( get_field( 'course_dates' ) ):
                                $fieldcoursedates = get_field( 'course_dates_for_frontend' );
                                $allcoursedates = explode( PHP_EOL, $fieldcoursedates );
                                $coursedates = array();
                                foreach ( $allcoursedates as $coursedate ):
                                    array_push( $coursedates, $coursedate );
                                endforeach;
                                echo "<ul class='coursedates'>";
                                foreach ( $coursedates as $coursedate ):
                                    echo "<li>".$coursedate."</li>";
                                endforeach;
                                echo "</ul>";
                            else:
                                echo "On-demand";
                            endif; ?>
                        </div>
                    </div>
                </div>

                <div class="time">
                    <div class="group">
                        <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_time .svg" alt=""
                            class="icon">
                        <div class="start-and-end-time">
                            <?php
                            if ( get_field( 'end_time' ) ):
                                echo '<span class="time">' . get_field( 'start_time' ) . '</span> - ' . get_field( 'end_time' );
                            else:
                                echo get_field( 'start_time' );
                            endif; ?>
                        </div>
                    </div>
                </div>

                <div class="location">
                    <div class="group">
                        <img src="<?php echo get_template_directory_uri() ?>/public/images/sift_location .svg" alt="" class="icon">
                        <span class="info">
                            <?php echo get_field( 'location' ); ?>
                        </span>
                        </div>
                </div>
            </div>

            <div class="description">
                <?php if( get_field( 'description' ) ) : ?>
                <h2 class="sub-heading">Course Description</h2>
                <p>
                    <?php echo get_field( 'description' ); ?>
                </p>
                <?php endif; ?>
            </div>

            <div class="training-wrapper">
                <div class="left-panel target-audience">
                    <?php 
                    if( get_field( 'prerequisites' ) ) :
                        echo "<h2 class='sub-heading'>Prerequisites</h2>";
                        $string = get_field( 'prerequisites' ); 
                        $prerequisites = explode( PHP_EOL, $string );
                        echo "<ul class='list'>";
                        foreach ( $prerequisites as $prerequisite ) :
                            echo "<li class='list-item'>" . $prerequisite . "</li>";
                        endforeach;
                        echo "</ul>";
                    endif;
                    ?>
                </div>
                <div class="right-panel prerequisites">
                    <?php 
                    if( get_field( 'target_audience' ) ) :
                        echo "<h2 class='sub-heading'>Target Audience</h2>";
                        $string = get_field( 'target_audience' );
                        $target_audiences = explode( PHP_EOL, $string );
                        echo "<ul class='list'>";
                        foreach ( $target_audiences as $target_audience ):
                            echo "<li class='list-item'>".$target_audience."</li>";
                        endforeach;
                        echo "</ul>";
                    endif;
                    ?>
                </div>
            </div>
            <a href="#register-here" class="sift-button">Register</a>
        </div>
</section>

<section class="cards-area">
    <?php the_content(); ?>
</section>

<section class="form-area" id="register-here">
    <div class="form-caption">
        <h3>Enquire / Register for this training course.</h3>
        <p>( <?php print the_title(); ?> )</p>
        <script>localStorage.setItem("courseName", "<?php print the_title(); ?>"); </script>
    </div>
    <?php echo (!empty(get_field('course_dates'))) ? do_shortcode( '[contact-form-7 id="7854" title="Register for the Training Course"]' ) : do_shortcode( '[contact-form-7 id="138" title="Enquire for the Training Course"]' ); ?>
</section>