<?php
use Mailgun\Api\Pagination;

/*
========================
        SIFT Supports Functions    
========================
*/
if( ! function_exists('sift_theme_support' ) ) :
    function sift_theme_support(){
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'custom-header' );
        add_theme_support( 'widgets' );
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'customize-selective-refresh-widgets' );
        add_theme_support( 'html5', [ 'script', 'style' ] );
        add_theme_support( 'html5', array( 
            'comment-list', 
            'comment-form', 
            'search-form', 
            'gallery', 
            'caption', 
            'style', 
            'script' 
        ) );
        add_theme_support( 'post-formats', array( 
            'aside', 
            'image', 
            'link', 
            'quote', 
            'status', 
            'gallery' 
        ) );
        add_theme_support( 'custom-logo', array(
            'height' => 480,
            'width'  => 720,
            'flex-height' => true,
            'flex-width' => true,
            'header-text' => array( 'site-title', 'site-description' ),
            'unlink-homepage-logo' => true,
        ) );
    }
endif;
add_action( 'after_setup_theme', 'sift_theme_support' );

/*
========================
                SIFT  Menus             
========================
*/
function sift_menus() {
    register_nav_menus( array(
        'primary_menu' => __( 'Primary Menu', 'primary_menu' ),
        'footer_menu'  => __( 'Footer Menu', 'footer_menu' ),
        'footer_menu_2'  => __( 'Footer Menu 2', 'footer_menu_2' ),
        'footer_menu_3'  => __( 'Footer Menu 3', 'footer_menu_3' ),
    ) );
}
add_action( 'after_setup_theme', 'sift_menus' );

/*
========================
                SIFT  Styles           
========================
*/
if( !function_exists( 'sift_styles' ) ) :
function sift_styles() {
    $theme_version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'core', get_stylesheet_uri(), array(), $theme_version );
    wp_enqueue_style( 'main', get_stylesheet_directory_uri() . '/public/css/main.css', $theme_version );
    wp_enqueue_style( 'responsive', get_stylesheet_directory_uri() . '/public/css/responsive.css', $theme_version );
}
endif;
add_action( 'wp_enqueue_scripts', 'sift_styles' );

/*
========================
                SIFT Scripts        
========================
*/
if( !function_exists( 'sift_scripts' ) ) :
function sift_scripts () {
    $theme_version = wp_get_theme()->get( 'Version' );
    if ( ( ! is_admin() ) && is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
    wp_enqueue_script( 'sift-script', get_template_directory_uri() . '/public/js/script.js', array(), $theme_version, false );
    wp_script_add_data( 'sift-script', 'async', true );
    wp_enqueue_script( 'download-script', get_template_directory_uri() . '/public/js/download.js', array(), $theme_version, false );
    wp_script_add_data( 'download-script', 'async', true );
    wp_enqueue_script( 'jquery', "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js", array(), null, true );
    wp_script_add_data( 'jquery', 'async', true );
}
endif;
add_action( 'wp_enqueue_scripts', 'sift_scripts' );

/*
========================
                SIFT Widgets        
========================
*/
if( !function_exists(' sift_widgets_init ') ):
function sift_widgets_init() {
    // First footer widget area, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Footer Widget Area 1', 'sift' ),
        'id' => 'first-footer-widget-area',
        'description' => __( 'The first footer widget area', 'sift' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 
    // Second Footer Widget Area, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Footer Widget Area 2', 'sift' ),
        'id' => 'second-footer-widget-area',
        'description' => __( 'The second footer widget area', 'sift' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 
    // Third Footer Widget Area, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Footer Widget Area 3', 'sift' ),
        'id' => 'third-footer-widget-area',
        'description' => __( 'The third footer widget area', 'sift' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
 
    // Fourth Footer Widget Area, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Footer Widget Area 4', 'sift' ),
        'id' => 'fourth-footer-widget-area',
        'description' => __( 'The fourth footer widget area', 'sift' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    // Fifth Footer Widget Area, located in the footer. Empty by default.
    register_sidebar( array(
        'name' => __( 'Footer Widget Area 5', 'sift' ),
        'id' => 'fifth-footer-widget-area',
        'description' => __( 'The fifth footer widget area', 'sift' ),
        'before_widget' => '<div id="%1$s" class="widget-container %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );         
}
endif; 
// Register sidebars by running sift_widgets_init() on the widgets_init hook.
add_action( 'widgets_init', 'sift_widgets_init' );

// Removing admin bar 
function remove_admin_bar() {
    if ( !current_user_can( 'administrator' ) && !is_admin() ) {
        show_admin_bar( false );
    } else {
        show_admin_bar(true);
    }
}
add_action( 'after_setup_theme', 'remove_admin_bar' );

// Login Page Customisation
function sift_custom_login() {
	echo '<link rel="stylesheet" type="text/css" href="' . get_template_directory_uri() . '/public/css/customlogin.css" />';
}
add_action( 'login_head', 'sift_custom_login' );

/*
=========================
        CPT Partners & Products          
=========================
*/
if( !function_exists( 'sift_partners_and_products' ) ) :
    function sift_partners_and_products() {
        // labels array added inside the function and precedes args array
        $labels = array(
            'name' => _x( 'Partners & Products', 'post type general name' ),
            'singular_name' => _x( 'Partner & Product', 'post type singular name' ),
            'add_new' => _x( 'Add New', 'Partner & Product' ),
            'add_new_item' => __( 'Add New Partner & Product' ),
            'edit_item' => __( 'Edit Partner & Product' ),
            'new_item' => __( 'New Partner & Product' ),
            'all_items' => __( 'All Partners & Products' ),
            'view_item' => __( 'View Partner & Product' ),
            'search_items' => __( 'Search Partners & Products' ),
            'not_found' => __( 'No Partners & Products found' ),
            'not_found_in_trash' => __( 'No Partners & Products found in the Trash' ),
            'parent_item_colon' => '',
            'supports' => array( 'title', 'page-attributes',  'editor', 'thumbnail', 'excerpt' ), 
            'menu_name' => 'Partners & Products',
        );
        
        // args array
        $args = array(
            'labels' => $labels,
            'description' => 'Displays SIFT Partners and Products',
            'public' => true,
            'menu_position' => 4,
            'menu_icon'=>'dashicons-buddicons-buddypress-logo',
            'has_archive' => true,
            'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            'rewrite' => array( 'slug' => 'partners-and-products', 'with_front' => false ),
        );
        
        register_post_type( 'partners', $args );
    }
endif;
add_action( 'init', 'sift_partners_and_products' );

// Custom Taxonomy for Trainings
if( !function_exists( 'sift_partners_and_products_taxonomies' ) ) :
    function sift_partners_and_products_taxonomies() {
        // labels array
        $labels = array(
            'name' => _x( 'Partners', 'taxonomy general name' ),
            'singular_name' => _x( 'Partner Category', 'taxonomy singular name' ),
            'search_items' => __( 'Search Categories' ),
            'all_items' => __( 'All Categories' ),
            'parent_item' => __( 'Parent Category' ),
            'parent_item_colon' => __( 'Parent Category:' ),
            'edit_item' => __( 'Edit Category' ),
            'update_item' => __( 'Update Category' ),
            'add_new_item' => __( 'Add New Category' ),
            'new_item_name' => __( 'New Category' ),
            'menu_name' => __( 'Partners' ),
        );
        
        // args array
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
            'show_admin_column' => true,
        );

        register_taxonomy( 'partners', 'partners', $args );

        // labels array
        $labels = array(
            'name' => _x( 'Products', 'taxonomy general name' ),
            'singular_name' => _x( 'Product Category', 'taxonomy singular name' ),
            'search_items' => __( 'Search Categories' ),
            'all_items' => __( 'All Categories' ),
            'parent_item' => __( 'Parent Category' ),
            'parent_item_colon' => __( 'Parent Category:' ),
            'edit_item' => __( 'Edit Category' ),
            'update_item' => __( 'Update Category' ),
            'add_new_item' => __( 'Add New Category' ),
            'new_item_name' => __( 'New Category' ),
            'menu_name' => __( 'Products' ),
        );
        
        // args array
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
            'show_admin_column' => true,
        );

        register_taxonomy( 'products', 'partners', $args );
    }
endif;
add_action( 'init', 'sift_partners_and_products_taxonomies', 0 );

/*
========================
                    CPT Story          
========================
*/
if( !function_exists( 'sift_story' ) ) :
    function sift_story() {
        // labels array added inside the function and precedes args array
        $labels = array(
            'name' => _x( 'Story', 'post type general name' ),
            'singular_name' => _x( 'Story', 'post type singular name' ),
            'add_new' => _x( 'Add New', 'Story' ),
            'add_new_item' => __( 'Add New Story' ),
            'edit_item' => __( 'Edit Story' ),
            'new_item' => __( 'New Story' ),
            'all_items' => __( 'All Stories' ),
            'view_item' => __( 'View Story' ),
            'search_items' => __( 'Search Stories' ),
            'not_found' => __( 'No Stories found' ),
            'not_found_in_trash' => __( 'No Stories found in the Trash' ),
            'parent_item_colon' => '',
            'supports'        => array( 'title', 'page-attributes','thumbnail' ), 
            'menu_name' => 'Story',
        );
        
        // args array
        
        $args = array(
            'labels' => $labels,
            'description' => 'Displays story of story',
            'public' => true,
            'menu_position' => 5,
            'menu_icon'=>'dashicons-admin-collapse',
            'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
            'has_archive' => true,
            'rewrite' => array( 'slug' => 'story', 'with_front' => false ),
        );
        
        register_post_type( 'story', $args );
    }
endif;
add_action( 'init', 'sift_story' );
    
/*
=================
           CPT Events          
=================
*/
if( !function_exists( 'sift_events' ) ) :
    function sift_events() {
        // labels array added inside the function and precedes args array
        $labels = array(
            'name' => _x( 'Events', 'post type general name' ),
            'singular_name' => _x( 'Event', 'post type singular name' ),
            'add_new' => _x( 'Add New', 'Event' ),
            'add_new_item' => __( 'Add New Event' ),
            'edit_item' => __( 'Edit Event' ),
            'new_item' => __( 'New Event' ),
            'all_items' => __( 'All Events' ),
            'view_item' => __( 'View Event' ),
            'search_items' => __( 'Search Events' ),
            'not_found' => __( 'No Events found' ),
            'not_found_in_trash' => __( 'No Events found in the Trash' ),
            'parent_item_colon' => '',
            'supports'        => array( 'title', 'page-attributes','thumbnail', 'editor' ), 
            'menu_name' => 'Events',
        );
        
        // args array
        $args = array(
            'labels' => $labels,
            'description' => 'Displays SIFT Events',
            'public' => true,
            'menu_position' => 6,
            'menu_icon'=>'dashicons-calendar-alt',
            'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
            'has_archive' => true,
            'rewrite' => array( 'slug' => 'events', 'with_front' => false ),
        );
        
        register_post_type( 'events', $args );
    }
endif;
add_action( 'init', 'sift_events' );

/*
========================
                CPT Trainings          
========================
*/
if( !function_exists( 'sift_trainings' ) ) :
    function sift_trainings() {        
        $labels = array(
            'name' => _x( 'Trainings', 'post type general name' ),
            'singular_name' => _x( 'Training', 'post type singular name' ),
            'add_new' => _x( 'Add New', 'Training' ),
            'add_new_item' => __( 'Add New Training' ),
            'edit_item' => __( 'Edit Training' ),
            'new_item' => __( 'New Training' ),
            'all_items' => __( 'All Training' ),
            'view_item' => __( 'View Training' ),
            'search_items' => __( 'Search Trainings' ),
            'not_found' => __( 'No Trainings found' ),
            'not_found_in_trash' => __( 'No Trainings found in the Trash' ),
            'parent_item_colon' => '',
            'supports'        => array( 'title', 'page-attributes', 'thumbnail' ), 
            'menu_name' => 'Trainings',
        );
        
        // args array
        $args = array(
            'labels' => $labels,
            'description' => 'Displays SIFT trainings',
            'public' => true,
            'menu_position' => 9,
            'menu_icon'=>'dashicons-editor-contract',
            'supports' => array( 'title', 'editor', 'thumbnail' ),
            'has_archive' => true,
            'rewrite' => array( 'slug' => 'training', 'with_front' => false ),
        );
        
        register_post_type( 'trainings', $args );
    }
endif;
add_action( 'init', 'sift_trainings' );

// Custom Taxonomy for Trainings
if( !function_exists( 'sift_trainings_taxonomies' ) ) :
    function sift_trainings_taxonomies() {
        // labels array
        $labels = array(
            'name' => _x( 'Training Categories', 'taxonomy general name' ),
            'singular_name' => _x( 'Training Category', 'taxonomy singular name' ),
            'search_items' => __( 'Search Categories' ),
            'all_items' => __( 'All Categories' ),
            'parent_item' => __( 'Parent Category' ),
            'parent_item_colon' => __( 'Parent Category:' ),
            'edit_item' => __( 'Edit Category' ),
            'update_item' => __( 'Update Category' ),
            'add_new_item' => __( 'Add New Category' ),
            'new_item_name' => __( 'New Category' ),
            'menu_name' => __( 'Training Categories' ),
        );
        
        // args array
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
        );

        register_taxonomy( 'trainings_category', 'trainings', $args );
    }
endif;
add_action( 'init', 'sift_trainings_taxonomies', 0 );

/*
========================
 Adding Dynamic Class to Body   
========================
*/
function my_body_classes( $classes ) {
    global $post;
    $name = $post->post_name;
    $classes[] = $name;
    return $classes;
}
add_filter( 'body_class', 'my_body_classes' );

/*
==============================
    Fetching SIFT Partners & Products  
==============================
*/
if( !function_exists( 'sift_partners_and_products_posts' ) ) :
    function sift_partners_and_products_posts( $atts ){
    // Shortcode attributes 
        $atts = shortcode_atts(
            array(
                'post_type' => 'partners',
                'post_status' => 'publish',
                'posts_per_page' => 9,
                'meta_key' => 'my_order',
                'orderby' => 'meta_value',
                'order' => 'ASC',
                'pagination' => 'true'
            ), $atts
        );
    
        $args = array(
            'post_type' => $atts['post_type'],
            'post_status' => $atts['post_status'],
            'posts_per_page' => $atts['posts_per_page'],
            'meta_key' => $atts['meta_key'],
            'orderby' => $atts['orderby'],
            'order' => $atts['order'],
            'pagination' => $atts['pagination'],
        );
        
        ob_start();

        $partnersandproducts = new WP_Query( $args );

        if( $partnersandproducts->have_posts() ) : ?>
        	<div class="partners-and-products-container">
             <?php   
            while( $partnersandproducts->have_posts() ) : $partnersandproducts->the_post(); ?>
            <article class="product card">
                <div class="card-inner">
                    <div class="thumbnail-image">
                        <?php echo the_post_thumbnail(); ?>
                    </div>
                    <div class="content">
                        <?php print the_excerpt(); ?>
                    </div>
                    <a href="<?php echo get_field( 'detail_page_url' ); ?>" class="button learn-more-btn">Learn More</a>
                </div>
            </article>
        <?php
            endwhile; ?>
            </div>
        <?php
        endif;
        $content = ob_get_clean();
        wp_reset_postdata(); 
        return $content;
    }
endif;
add_shortcode( 'partners_and_products', 'sift_partners_and_products_posts' );

/*
========================
    Fetching SIFT Story Posts  
========================
*/
if( !function_exists( 'sift_story_posts' ) ) :
function sift_story_posts( $atts ){

// Shortcode attributes 
    $atts = shortcode_atts(
		array(
			'post_type' => 'story',
			'post_status' => 'publish',
			'posts_per_page' => 3,
			'orderby' => 'date',
			'order' => 'ASC',
			'pagination' => 'true'
		), $atts
	);

    $args = array(
        'post_type' => $atts['post_type'],
        'post_status' => $atts['post_status'],
        'posts_per_page' => $atts['posts_per_page'],
        'orderby' => $atts['orderby'],
        'order' => $atts['order'],
        'pagination' => $atts['pagination'],
    );

	ob_start();

	$stories = new WP_Query( $args ); ?>
	<div class="story-container">
	<?php
    if( $stories->have_posts() ) :
		while ( $stories->have_posts() ) : $stories->the_post(); ?>
		<article class="story">
            <div class="story-thumbnail">
                <?php the_post_thumbnail(); ?>
            </div>
            <div class="story-info">
            <h2> <?php the_title(); ?></h2>
                <small class="excerpt"><?php the_excerpt(); ?>
                <?php if( get_field( 'sift_story_detail_url' ) ) : ?>
                    <a href="<?php echo get_field( 'sift_story_detail_url' ); ?>" target="_blank">Read More</a>
                <?php elseif( get_field( 'story_video_url' ) ) : ?>
                    <a href="<?php echo get_field( 'story_video_url' ); ?>" target="_blank">Watch On-Demand</a>
                <?php endif; ?>
                </small>
            </div>
        </article>
	<?php endwhile; ?>
    <?php endif; ?>
	</div>
	<?php
        $content = ob_get_clean();
        wp_reset_postdata(); 
        return $content;
	}
endif;
add_shortcode( 'sift_stories', 'sift_story_posts' );

/*
=============================
   Fetching SIFT Trainings Post (IBM)
=============================
*/

if( !function_exists( 'sift_trainings_ibm_post' ) ) :
    function sift_trainings_ibm_post(){
        $trainings = array(
            'post_type' => 'trainings',
            'showposts' => 3, 
            'tax_query' => array(
                array(
                    'taxonomy' => 'trainings_category',
                    'field' => 'slug',
                    'terms' => 'ibm', 
                )
            )
        );
        ob_start();
        $ibm = new WP_Query( $trainings );
        while( $ibm->have_posts() ) :
        $ibm->the_post(); ?>
            <div class="training-thumbnail ibm">
                <?php the_post_thumbnail(); ?>
            </div>
            <article class="cards cards-ibm">
            <div class="card-inner">
                 <h4><?php print the_title(); ?></h4>
                 <p class="course-duration"><?php echo get_field( 'training_duration' ); ?> Course</p>
                 <a href="<?php the_permalink(); ?>" class="course-detail-btn">Course Details</a>
            </div>
         </article>
        <?php
         endwhile;
        $content = ob_get_clean();
        wp_reset_postdata();
        return $content;
    }
endif;
add_shortcode( 'sift_trainings_ibm', 'sift_trainings_ibm_post' );

/*
=============================
   Fetching SIFT Trainings Post (Qlik)
=============================
*/
if( !function_exists( 'sift_trainings_qlik_post' ) ) :
    function sift_trainings_qlik_post(){
        $trainings = array(
            'post_type' => 'trainings',
            'showposts' => 4, 
            'tax_query' => array(
                array(
                    'taxonomy' => 'trainings_category',
                    'field' => 'slug',
                    'terms' => 'qlik', 
                )
            )
        );
        ob_start();
        $qlik = new WP_Query( $trainings );
        while( $qlik->have_posts() ) :
            $qlik->the_post(); ?>
                <div class="training-thumbnail qlik">
                    <?php the_post_thumbnail(); ?>
                </div>
                <article class="cards cards-qlik">
                <div class="card-inner">
                     <h4><?php print the_title(); ?></h4>
                     <p class="course-duration"><?php echo get_field( 'training_duration' ); ?> Course</p>
                     <a href="<?php the_permalink(); ?>" class="course-detail-btn">Course Details</a>
                </div>
             </article>
            <?php
             endwhile;
        $content = ob_get_clean();
        wp_reset_postdata();
        return $content;
    }
endif;
add_shortcode( 'sift_trainings_qlik', 'sift_trainings_qlik_post' );

/*
================================
   Fetching SIFT Trainings Post (alteryx)
================================
*/
if( !function_exists( 'sift_trainings_alteryx_post' ) ) :
    function sift_trainings_alteryx_post(){
        $trainings = array(
            'post_type' => 'trainings',
            'showposts' => 2, 
            'tax_query' => array(
                array(
                    'taxonomy' => 'trainings_category',
                    'field' => 'slug',
                    'terms' => 'alteryx', 
                )
            )
        );
        ob_start();
        $qlik = new WP_Query( $trainings );
        while( $qlik->have_posts() ) :
        $qlik->the_post(); ?>
        <div class="training-thumbnail alteryx">
            <?php the_post_thumbnail(); ?>
        </div>
        <article class="cards cards-alteryx">
            <div class="card-inner">
                <h4><?php print the_title(); ?></h4>
                <p class="course-duration"><?php echo get_field( 'training_duration' ); ?> Course</p>
                <a href="<?php the_permalink(); ?>" class="course-detail-btn">Course Details</a>
            </div>
        </article>
        <?php
        endwhile;
        $content = ob_get_clean();
        wp_reset_postdata();
        return $content;
    }
endif;
add_shortcode( 'sift_trainings_alteryx', 'sift_trainings_alteryx_post' );

/*
===============
            Events
===============
*/
if( !function_exists( 'sift_events_tab') ) :
    function sift_events_tab() { 
        ob_start(); ?>

        <!-- Events Tab -->
        <ul class="events-tab" id="events-tab">
            <li class="cat-item active" name="All Events">
                <a href="#">All Events</a>
            </li>
            <li class="cat-item" name="Upcoming Events">
                <a href="#">Upcoming Events</a>
            </li>
            <li class="cat-item" name="Past Events">
                <a href="#">Past Events</a>
            </li>
        </ul>

        <!-- Events Container -->
        <div class="events-container">
            <h2 class="active-event">All Events</h2>
                <div class="post-events">
                    <div class="events-inner">
                        <?php echo do_shortcode( '[sift_all_events]' ); ?>
                    </div>
                </div>
        </div>
    <?php
        $content = ob_get_clean(); 
        wp_reset_postdata();
        return $content;
    }
endif;
add_shortcode( 'sift_events_tab_frontend', 'sift_events_tab' );

if( !function_exists( 'all_events') ) :
function all_events() {
    $args = array(
        'post_type' => 'events',
        'posts_per_page' => 9,
        'paged' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1,
        'post_status' => 'publish',
        'orderby' => 'meta_value',
        'meta_key' => 'start_date',
        'order' => 'DESC',
    );

    $allevents = new WP_Query( $args );
        if ( $allevents->have_posts() ):
            echo "<div class='events'>";
            while( $allevents->have_posts() ) : $allevents->the_post();
                get_template_part( 'template-parts/content', 'events' );
            endwhile;
            echo "</div>";
            wp_reset_postdata();
        endif;
        // Pagination
        echo "<div class='pagination'>" . paginate_links( 
            array(
                'base' => get_home_url() . '/events/' . '%_%',
                'format' => '?paged=%#%',
                'current' => max( 1, get_query_var( 'paged' ) ),
                'total' => $allevents->max_num_pages,
            ) 
        ) . "</div>";
}
endif;
add_shortcode( 'sift_all_events', 'all_events' );

// Events Specific Scripts 
if( !function_exists( 'my_enqueue_events ' ) ) :
    function my_enqueue_events() {
        wp_enqueue_script( 'ajax-script', get_template_directory_uri().'/public/js/event.js', array('jquery') );
        wp_localize_script( 'ajax-script', 'my_ajax_object',
            array( 
                'ajax_url' => admin_url( 'admin-ajax.php' )
            ) 
        );
    }
endif;
add_action( 'wp_enqueue_scripts', 'my_enqueue_events' );

// AJAX Hooks 
add_action( 'wp_ajax_nopriv_filterEvents', 'filterEvents' ); 
add_action( 'wp_ajax_filterEvents', 'filterEvents' );

function filterEvents() {
    $name = $_REQUEST[ 'name' ];
    if( $name == "Past Events" ) :      
        $args = array(
            'post_type' => 'events',
            'posts_per_page' => 9,
            'paged' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1, 
            'meta_key' => 'start_date',
            'orderby' => 'meta_value',
            'order' => 'DESC',
            'meta_query' => array(
                array(
                    'key' => 'start_date',
                    'value' => date( "Y-m-d" ),
                    'type'=> 'DATE',
                    'compare' => '<',
                )
            )
        );

        $pastevents = new WP_Query( $args );
        if ($pastevents->have_posts()):
            echo "<div class='events'>";
            while( $pastevents->have_posts() ) : $pastevents->the_post();
                get_template_part( 'template-parts/content', 'events' );
            endwhile;
            echo "</div>";
            wp_reset_postdata();
        endif;
        // Pagination
        // echo "<div class='pagination'>" . paginate_links( 
        //     array(
        //         'base' => get_home_url() . '/events/' . '%_%',
        //         'format' => '?paged=%#%',
        //         'current' => max( 1, get_query_var( 'paged' ) ),
        //         'total' => $pastevents->max_num_pages,
        //     ) 
        // ) . "</div>";

    elseif( $name == "Upcoming Events" ) :
        $args = array(
            'post_type' => 'events',
            'posts_per_page' => 9,
            'paged' => get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1, 
            'meta_key' => 'start_date',
            'orderby' => 'meta_value',
            'order' => 'DESC',
            'post_status' => array( 'publish' ),
            'meta_query' => array(
                array(
                    'key' => 'start_date',
                    'value' => date( "Y-m-d" ),
                    'type'=> 'DATE',
                    'compare' => '>',
                )
            )
        );
    
        $upcommingevents = new WP_Query( $args );
        if ($upcommingevents->have_posts()):
            echo "<div class='events'>";
            while( $upcommingevents->have_posts() ) : $upcommingevents->the_post();
                get_template_part( 'template-parts/content', 'events' );
            endwhile;
            echo "</div>";
            wp_reset_postdata();
        endif;
        // Pagination
        // echo "<div class='pagination'>" . paginate_links( 
        //     array(
        //         'base' => get_home_url() . '/events/' . '%_%',
        //         'format' => '?paged=%#%',
        //         'current' => max( 1, get_query_var( 'paged' ) ),
        //         'total' => $upcommingevents->max_num_pages,
        //     ) 
        // ) . "</div>";
    else:
        echo do_shortcode( '[sift_all_events]' );
    endif;
    wp_die();
}

// AJAX Hooks for Events Pagination
add_action( 'wp_ajax_nopriv_eventsPagination', 'eventsPagination' ); 
add_action( 'wp_ajax_eventsPagination', 'eventsPagination' );
function eventsPagination() {
    $pageNumber = $_REQUEST['pageNumber'];
    if( !empty( $pageNumber ) && isset( $pageNumber )) {
        $args = array(
            'post_type' => 'events',
            'posts_per_page' => 9,
            'paged' => $pageNumber,
            'post_status' => 'publish',
        );
    }

    $results = new WP_Query( $args );
        if( $results->have_posts() ) : 
            while( $results->have_posts() ) : $results->the_post();
                get_template_part( 'template-parts/content', 'events' );
            endwhile;
            wp_reset_postdata();
        endif;
    wp_die();
}

// Contact Form  7 Custom Email Validation 
function is_business_email( $email ){
	if( preg_match( '/@hotmail.com/i', $email ) ||
		preg_match( '/@gmail.com/i', $email ) ||
		preg_match( '/@yahoo.co/i', $email ) ||
		preg_match( '/@yahoo.com/i', $email ) ||
		preg_match( '/@mailinator.com/i', $email ) ||
		preg_match( '/@gmail.co.in/i', $email ) ||
		preg_match( '/@aol.com/i', $email ) ||
		preg_match( '/@yandex.com/i', $email ) ||
		preg_match( '/@msn.com/i', $email ) ||
		preg_match( '/@gawab.com/i', $email ) ||
		preg_match( '/@inbox.com/i', $email ) ||
		preg_match( '/@gmx.com/i', $email ) ||
		preg_match( '/@rediffmail.com/i', $email ) ||
		preg_match( '/@in.com/i', $email ) ||
		preg_match( '/@live.com/i', $email ) ||
		preg_match( '/@hotmail.co.uk/i', $email ) ||
		preg_match( '/@hotmail.fr/i', $email ) ||
		preg_match( '/@yahoo.fr/i', $email ) ||
		preg_match( '/@wanadoo.fr/i', $email ) ||
		preg_match( '/@wanadoo.fr/i', $email ) ||
		preg_match( '/@comcast.net/i', $email ) ||
		preg_match( '/@yahoo.co.uk/i', $email ) ||
		preg_match( '/@yahoo.com.br/i', $email ) ||
		preg_match( '/@yahoo.co.in/i', $email ) ||
		preg_match( '/@rediffmail.com/i', $email ) ||
		preg_match( '/@free.fr/i', $email ) ||
		preg_match( '/@gmx.de/i', $email ) ||
		preg_match( '/@gmx.de/i', $email ) ||
		preg_match( '/@yandex.ru/i', $email ) ||
		preg_match( '/@ymail.com/i', $email ) ||
		preg_match( '/@libero.it/i', $email ) ||
		preg_match( '/@outlook.com/i', $email ) ||
		preg_match( '/@uol.com.br/i', $email ) ||
		preg_match( '/@bol.com.br/i', $email ) ||
		preg_match( '/@mail.ru/i', $email ) ||
		preg_match( '/@cox.net/i', $email ) ||
		preg_match( '/@hotmail.it/i', $email ) ||
		preg_match( '/@sbcglobal.net/i', $email ) ||
		preg_match( '/@sfr.fr/i', $email ) ||
		preg_match( '/@live.fr/i', $email ) ||
		preg_match( '/@verizon.net/i', $email ) ||
		preg_match( '/@live.co.uk/i', $email ) ||
		preg_match( '/@googlemail.com/i', $email ) ||
		preg_match( '/@yahoo.es/i', $email ) ||
		preg_match( '/@ig.com.br/i', $email ) ||
		preg_match( '/@live.nl/i', $email ) ||
		preg_match( '/@bigpond.com/i', $email ) ||
		preg_match( '/@terra.com.br/i', $email ) ||
		preg_match( '/@yahoo.it/i', $email ) ||
		preg_match( '/@neuf.fr/i', $email ) ||
		preg_match( '/@yahoo.de/i', $email ) ||
		preg_match( '/@live.com/i', $email ) ||
		preg_match( '/@yahoo.de/i', $email ) ||
		preg_match( '/@rocketmail.com/i', $email ) ||
		preg_match( '/@att.net/i', $email ) ||
		preg_match( '/@laposte.net/i', $email ) ||
		preg_match( '/@facebook.com/i', $email ) ||
		preg_match( '/@bellsouth.net/i', $email ) ||
		preg_match( '/@yahoo.in/i', $email ) ||
		preg_match( '/@hotmail.es/i', $email ) ||
		preg_match( '/@charter.net/i', $email ) ||
		preg_match( '/@yahoo.ca/i', $email ) ||
		preg_match( '/@yahoo.com.au/i', $email ) ||
		preg_match( '/@rambler.ru/i', $email ) ||
		preg_match( '/@hotmail.de/i', $email ) ||
		preg_match( '/@tiscali.it/i', $email ) ||
		preg_match( '/@shaw.ca/i', $email ) ||
		preg_match( '/@yahoo.co.jp/i', $email ) ||
		preg_match( '/@sky.com/i', $email ) ||
		preg_match( '/@earthlink.net/i', $email ) ||
		preg_match( '/@optonline.net/i', $email ) ||
		preg_match( '/@freenet.de/i', $email ) ||
		preg_match( '/@t-online.de/i', $email ) ||
		preg_match( '/@aliceadsl.fr/i', $email ) ||
		preg_match( '/@virgilio.it/i', $email ) ||
		preg_match( '/@home.nl/i', $email ) ||
		preg_match( '/@qq.com/i', $email ) ||
		preg_match( '/@telenet.be/i', $email ) ||
		preg_match( '/@me.com/i', $email ) ||
		preg_match( '/@yahoo.com.ar/i', $email ) ||
		preg_match( '/@tiscali.co.uk/i', $email ) ||
		preg_match( '/@yahoo.com.mx/i', $email ) ||
		preg_match( '/@gmx.net/i', $email ) ||
		preg_match( '/@mail.com/i', $email ) ||
		preg_match( '/@planet.nl/i', $email ) ||
		preg_match( '/@tin.it/i', $email ) ||
		preg_match( '/@live.it/i', $email ) ||
		preg_match( '/@ntlworld.com/i', $email ) ||
		preg_match( '/@arcor.de/i', $email ) ||
		preg_match(' /@yahoo.co.id/i', $email ) ||
		preg_match(' /@frontiernet.net/i', $email ) ||
		preg_match(' /@hetnet.nl/i', $email ) ||
		preg_match(' /@live.com.au/i', $email ) ||
		preg_match(' /@yahoo.com.sg/i', $email ) ||
		preg_match(' /@zonnet.nl/i', $email ) ||
		preg_match(' /@club-internet.fr/i', $email ) ||
		preg_match(' /@juno.com/i', $email ) ||
		preg_match(' /@optusnet.com.au/i', $email ) ||
		preg_match(' /@blueyonder.co.uk/i', $email ) ||
		preg_match(' /@bluewin.ch/i', $email ) ||
		preg_match(' /@skynet.be/i', $email ) ||
		preg_match(' /@sympatico.ca/i', $email ) ||
		preg_match(' /@windstream.net/i', $email ) ||
		preg_match(' /@mac.com/i', $email ) ||
		preg_match(' /@centurytel.net/i', $email ) ||
		preg_match(' /@chello.nl/i', $email) ||
		preg_match(' /@live.ca/i', $email ) ||
		preg_match(' /@aim.com/i', $email ) ||
		preg_match(' /@bigpond.net.au/i', $email ))
	{
		return false; 
	}
	else{
		return true; 
	}
}
function custom_email_validation_filter( $result, $tag ) {
	$tag = new WPCF7_Shortcode( $tag );
	if ( 'email' == $tag->name ) {
		$the_value = isset( $_POST['email'] ) ? trim( $_POST['email'] ) : "";

		if( !is_business_email( $the_value ) ){
			$result->invalidate( $tag, "Please enter a valid business email" );
		}
	}
	return $result;
}
add_filter( 'wpcf7_validate_email', 'custom_email_validation_filter', 10, 2 );
add_filter( 'wpcf7_validate_email*', 'custom_email_validation_filter', 10, 2 );

// Dynamic Country Dropdown Based on IP
add_filter( 'wpcf7_form_tag_data_option', function( $n, $options ) {
if( in_array( 'countrylists', $options ) ){
    $countrylists = array(
        "Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Democratic Republic of the Congo (Kinshasa)", "Congo, Republic of (Brazzaville)", "Cook Islands", "Costa Rica", "Côte D'ivoire (Ivory Coast)", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor (Timor-Leste)", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "The Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Holy See", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Ivory Coast", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Rep. (North Korea)", "Korea, Republic of (South Korea)", "Kosovo", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federal States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Myanmar, Burma", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "North Macedonia", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Palestinian territories", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn Island", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion Island", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Sudan", "Spain", "Sudan", "Suriname", "Swaziland (Eswatini)", "Sweden", "Switzerland", "Syria, Syrian Arab Republic", "Taiwan (Republic of China)", "Tajikistan", "Tanzania; officially the United Republic of Tanzania", "Thailand", "Tibet", "Timor-Leste (East Timor)", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Sri Lanka", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City State (Holy See)", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Zambia", "Zimbabwe"
    );
    return $countrylists;
}
return $n;
}, 10, 3);

function countryLists() {
    $ip = @$_SERVER[ 'HTTP_CLIENT_IP' ];
    $ipdata = json_decode( file_get_contents( 'http://www.geoplugin.net/json.gp?ip='.$ip ) );
    $cookie_name = "country";
    $cookie_value = $ipdata->geoplugin_countryName;
    setcookie( $cookie_name, $cookie_value );
}
add_action( 'init', 'countryLists' ); 

// IP Based Country Postal Code 
function postalCode() {
    $ip = @$_SERVER[ 'HTTP_CLIENT_IP' ];
    $postalCode = json_decode( file_get_contents( 'https://ipapi.co/'.$ip.'/postal/' ) );
    $cookie_name = "postal_code";
    $cookie_value = $postalCode;
    setcookie( $cookie_name, $cookie_value );
}
add_action( 'init', 'postalCode' ); 

// Dynamic Course Date Binding for Training Page 
add_filter( 'wpcf7_form_tag_data_option', function( $n, $options ) {
    if( in_array( 'coursedates', $options ) ){
        $fieldcoursedates = get_field( 'course_dates' );
        $allcoursedates = explode( PHP_EOL, $fieldcoursedates );
        $coursedates = array();
        foreach ( $allcoursedates as $coursedate ):
            array_push( $coursedates, $coursedate );
        endforeach;
        return $coursedates;
    }
    return $n;
}, 10, 3 );

// Remove <p> and <br/> from Contact Form 7
add_filter('wpcf7_autop_or_not', '__return_false');
