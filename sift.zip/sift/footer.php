        <footer id="sift_footer" class="sift_footer">
        <?php get_template_part( 'template-parts/content', 'footer' ); ?>
          <div class="copyright-declaration">
            <p>Copyright&copy; <span class="date"><?php echo date( 'Y' ); ?></span> <span class="brand-name"><?php bloginfo('name'); ?></span> Analytics Group All Rights Reserved.</p>
          </div>
        </footer>
        <?php wp_footer(); ?>
    </body>
</body>
</html>