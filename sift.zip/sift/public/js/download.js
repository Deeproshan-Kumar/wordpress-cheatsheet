// Product Page Specific Script 

// Product Page File Download Script (Alteryx)
document.addEventListener('wpcf7mailsent', function(e){
    if('6038' == e.detail.contactFormId) {
        let alteryxDownload = "https://php8.singsys.net/sift/download/7890/?tmstv=1675860717",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", alteryxDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Product Page File Download Script (IBM)
document.addEventListener('wpcf7mailsent', function(e){
    if('6043' == e.detail.contactFormId) {
        let ibmDownload = "https://php8.singsys.net/sift/download/7894/?tmstv=1675860936",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", ibmDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Product Page File Download Script (Tableau)
document.addEventListener('wpcf7mailsent', function(e){
    if('6046' == e.detail.contactFormId) {
        let tableauDownload = "https://php8.singsys.net/sift/download/7892/?tmstv=1675860847",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", tableauDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Qlik Page File Download Script (Sales)
document.addEventListener('wpcf7mailsent', function(e){
    if('6785' == e.detail.contactFormId) {
        let qlikDownload = "https://php8.singsys.net/sift/download/6790/?tmstv=1675771495",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", qlikDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

document.addEventListener('wpcf7mailsent', function(e){
    if('6787' == e.detail.contactFormId) {
        let qlikDownload_2 = "https://php8.singsys.net/sift/download/6793/?tmstv=1675771495",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", qlikDownload_2);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page Specific Script 
// Solutions Page File Download Script (Communications)
document.addEventListener('wpcf7mailsent', function(e){
    if('6526' == e.detail.contactFormId) {
        let commDownload = "https://php8.singsys.net/sift/download/6550/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", commDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Consumer products)
document.addEventListener('wpcf7mailsent', function(e){
    if('6528' == e.detail.contactFormId) {
        let consumerDownload = "https://php8.singsys.net/sift/download/6553/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", consumerDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Education)
document.addEventListener('wpcf7mailsent', function(e){
    if('6530' == e.detail.contactFormId) {
        let eduDownload = "https://php8.singsys.net/sift/download/6556/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", eduDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Financial Services)
document.addEventListener('wpcf7mailsent', function(e){
    if('6532' == e.detail.contactFormId) {
        let financialDownload = "https://php8.singsys.net/sift/download/6559/?tmstv=1678896533",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", financialDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Government)
document.addEventListener('wpcf7mailsent', function(e){
    if('6534' == e.detail.contactFormId) {
        let governmentDownload = "https://php8.singsys.net/sift/download/6562/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", governmentDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Healthcare)
document.addEventListener('wpcf7mailsent', function(e){
    if('6536' == e.detail.contactFormId) {
        let healthcareDownload = "https://php8.singsys.net/sift/download/6565/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", healthcareDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Manufacturing)
document.addEventListener('wpcf7mailsent', function(e){
    if('6538' == e.detail.contactFormId) {
        let manufacturingDownload = "https://php8.singsys.net/sift/download/6568/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", manufacturingDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Retail)
document.addEventListener('wpcf7mailsent', function(e){
    if('6540' == e.detail.contactFormId) {
        let retailDownload = "https://php8.singsys.net/sift/download/6571/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", retailDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Finance)
document.addEventListener('wpcf7mailsent', function(e){
    if('6542' == e.detail.contactFormId) {
        let financeDownload = "https://php8.singsys.net/sift/download/6574/?tmstv=1678896533",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", financeDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Human Resources)
document.addEventListener('wpcf7mailsent', function(e){
    if('6544' == e.detail.contactFormId) {
        let hrDownload = "https://php8.singsys.net/sift/download/6577/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", hrDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Marketing)
document.addEventListener('wpcf7mailsent', function(e){
    if('6546' == e.detail.contactFormId) {
        let markettingDownload = "https://php8.singsys.net/sift/download/6580/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", markettingDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);

// Solutions Page File Download Script (Sales)
document.addEventListener('wpcf7mailsent', function(e){
    if('6548' == e.detail.contactFormId) {
        let salesDownload = "https://php8.singsys.net/sift/download/6583/?tmstv=1673527149",
        aElement = document.createElement("a"),
        body = document.body;
        aElement.setAttribute("href", salesDownload);
        aElement.setAttribute("download", "");
        aElement.setAttribute("target", "_self");
        body.appendChild(aElement);
        aElement.click();
        body.removeChild(aElement);
    }
}, false);