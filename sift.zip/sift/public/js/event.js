// Events Tabs Functionality
jQuery(document).on('click', '.events-tab .cat-item', function(e){
    e.preventDefault();
    jQuery('.cat-item').removeClass('active');
    jQuery(this).addClass('active');
    var name = jQuery(this).attr('name'); // Getting value of name attribute from <li>.
    // console.log(category);
    jQuery.ajax({
        type: 'post',
        dataType: 'html',
        url: my_ajax_object.ajax_url,
        data: { action: "filterEvents", name: name },
        success: function(res) {
            jQuery('.events-container .active-event').text(name);
            jQuery('.events-container .events').html(res);
        },
        error: function(res){
            console.log(res);
        }
    });
});

// Pagination
// jQuery(document).on('click','.pagination .page-numbers', function(e){
//         e.preventDefault();
//         jQuery('.page-numbers').removeClass('current');
//         jQuery(this).addClass('current');
//         var pageLink = jQuery(this).attr('href');
//         var pageNumber = pageLink.substr(-1);
//         if(pageNumber == '/'){
//             pageNumber = pageLink.slice(0,-1).substr(-1);
//         }
//         jQuery.ajax({
//             type: 'post',
//             dataType: 'html',
//             url: my_ajax_object.ajax_url,
//             data: { action: "eventsPagination", pageNumber: pageNumber },
//             success: function(res) {
//                 jQuery('.events-container .events .events').html(res);
//             },
//             error: function(res){
//                 console.log(res);
//             }
//         });
// });
