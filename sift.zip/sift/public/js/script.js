// Script for responsive menu 
window.addEventListener("DOMContentLoaded", function(){
    let hamburger = document.querySelector('.hamburger');
    let menu = document.querySelector('.menu');
    if(hamburger) {
        hamburger.addEventListener('click', ()=> {
            hamburger.classList.toggle('active');
            if(menu) {
                menu.classList.toggle('active');
            }
        });
    }

    // Sticky menu 
    let navbar = document.querySelector('.navbar');
    if(navbar) {
        window.addEventListener('scroll', ()=> {
            navbar.classList.toggle('sticky', window.scrollY > navbar.offsetHeight);
        });
    }

    // Contact Form 7 Custom Validation Message Positioning 
    const wpContactForms = document.querySelectorAll(".sift.form-container");
    wpContactForms.forEach(wpContactForm=>{
    const div = document.createElement("div"); 
    div.setAttribute("class", "validation-message");
    div.setAttribute("id", "validation-message");
    wpContactForm.appendChild(div);
    document.addEventListener( 'wpcf7submit', function ( event ) {
            const status = event.detail;
            let invalidFields = status.apiResponse.invalid_fields;
            invalidFields.forEach(invalidField=>{
                if(invalidField.field == "email") {
                    div.textContent = invalidField.message;
                } else {
                    div.textContent =  status.apiResponse.message;
                }
            });
        });
    });

    // Contact Form 7 Autofill Functionality Implementation Using Cookies 
    wpContactForms.forEach(wpContactForm=>{
        const firstName = wpContactForm.querySelector("input.first-name"),
        lastName = wpContactForm.querySelector("input.last-name"),
        email = wpContactForm.querySelector("input.email"),
        orgName = wpContactForm.querySelector("input.organisation-name"),
        jobTitle = wpContactForm.querySelector("input.job-title"),
        phoneNumber = wpContactForm.querySelector("input.phone-number");

        if(firstName || lastName || email || orgName || jobTitle || phoneNumber) {
            firstName && firstName.addEventListener("change", getVal);
            lastName && lastName.addEventListener("change", getVal);
            email && email.addEventListener("change", getVal);
            orgName && orgName.addEventListener("change", getVal);
            jobTitle && jobTitle.addEventListener("change", getVal);
            phoneNumber && phoneNumber.addEventListener("change", getVal);
        }
        
        function getVal() {
            let fName = firstName.value;
            let lName = lastName.value;
            let emailId = email.value;
            let oName = orgName.value;
            let jTitle = jobTitle.value;
            let phoneNum = phoneNumber.value;
            document.cookie = `cf7=${fName}, ${lName}, ${emailId}, ${oName}, ${jTitle}, ${phoneNum}; path=/`;
        }

        const cookies = document.cookie.split(";");
        
        cookies.forEach(cookie=>{
            if(cookie.includes("cf7")) {
                let arrOfFormVals;
                arrOfFormVals = cookie.replace("cf7=","").split(","); // Cookies in Array form

                // Setting value to the form 
                ( jQuery(".first-name") ? jQuery(".first-name").val(arrOfFormVals[0].trim()) : "" );
                ( jQuery(".last-name") ? jQuery(".last-name").val(arrOfFormVals[1].trim()) : "" );
                ( jQuery(".email") ? jQuery(".email").val(arrOfFormVals[2].trim()) : "" );
                ( jQuery(".organisation-name") ? jQuery(".organisation-name").val(arrOfFormVals[3].trim()) : "" );
                ( jQuery(".job-title") ? jQuery(".job-title").val(arrOfFormVals[4].trim()) : "" );
                ( jQuery(".phone-number") ? jQuery(".phone-number").val(arrOfFormVals[5].trim()) : "" );

                // Hiding field label if the value is set 
                ( jQuery(".first-name") && jQuery(".first-name").val(arrOfFormVals[0].trim()) ? jQuery(".first-name").find("label").css("display", "none") : "" );
                ( jQuery(".last-name") && jQuery(".last-name").val(arrOfFormVals[1].trim()) ? jQuery(".last-name").find("label").css("display", "none") : "" );
                ( jQuery(".email") && jQuery(".email").val(arrOfFormVals[2].trim()) ? jQuery(".email").find("label").css("display", "none") : "" );
                ( jQuery(".organisation-name") && jQuery(".organisation-name").val(arrOfFormVals[3].trim()) ? jQuery(".organisation-name").find("label").css("display", "none") : "" );
                ( jQuery(".job-title") && jQuery(".job-title").val(arrOfFormVals[4].trim()) ? jQuery(".job-title").find("label").css("display", "none") : "" );
                ( jQuery(".phone-number") && jQuery(".phone-number").val(arrOfFormVals[5].trim()) ? jQuery(".phone-number").find("label").css("display", "none") : "" );
            }
        });
    });
    
    // Contact Form Script 
    let inputs = document.querySelectorAll('.sift.form-container input');
    if(inputs) {
        inputs.forEach(input=>{
            input.addEventListener('keyup', function(){
                if(input.value == "") {
                    this.parentElement.nextElementSibling.style.display="block";
                } else {
                    this.parentElement.nextElementSibling.style.display="none";
                }
            });
        });
    }
   
    let selects = document.querySelectorAll('.sift.form-container .field .course-date');
    if(selects) {
        selects.forEach(select=>{
            let options = document.querySelectorAll('.sift.form-container .field  .course-date option');
            options.forEach(option=>{
                if(option.value == "") {
                    option.innerText = "";
                }
            })
            select.addEventListener('change', function(){
                    this.parentElement.nextElementSibling.style.display="none";
            });
        });
    }

    // Training Detail Page Script
    const backButton = document.querySelector(".back-button .elementor-button-link");
    if(backButton) {
        backButton.addEventListener("click", function(e){
            e.preventDefault();
            window.open(document.referrer, "_self");
        });
    }
    
    const currentUrl = window.location.href,
    menus = document.querySelectorAll('.menu-item');
    if (currentUrl.includes("training")) {
        menus.forEach(menu=>{
            const navLink = menu.querySelector('a').textContent;
            if(navLink == "Training") {
                menu.classList.add("current-menu-item");
            }
        });
    }

    const courseName = document.querySelector(".course-name");
    if(courseName) { 
        courseName.value = localStorage.getItem("courseName"); 
    }


    // Checkbox logic 
    const checkbox = document.querySelector("input[type='checkbox']"),
    check = document.querySelector(".checkbox-status");
    if(check && checkbox) {
        check.value = "NO";
        checkbox.addEventListener("click", function() {
            if (checkbox.checked == true){
                check.value = "YES";
            } else {
            check.value = "NO";
            }
        });
    }

    // Bottom to Top Button Script
    const bottomToTop = document.querySelector('.bottom-to-top');
    if(bottomToTop) {
        window.addEventListener('scroll', ()=> {
            bottomToTop.classList.toggle('show', window.scrollY > 300);
        });
    }

    // Footer Social Script 
    const socialLinks = document.querySelectorAll('.sift_footer .wp-social-link a');
    if(socialLinks) {
        socialLinks.forEach(link=>{
            link.setAttribute('target', '_blank'); 
        });
    }

    // Event Page Script (Auto downloading)
    const ebd_link = document.querySelector('.ebd_link ');
    if(ebd_link) {
        ebd_link.click();
    }

    // Mobile Country Dropdown Auto Select Script 
    const URL = `https://ipapi.co/country_calling_code/`;
    async function fetchMobileCode(url){
        try {
            const response = await fetch(url),
            data = await response.text(),
            options = document.querySelectorAll('.country-code option');
            options.forEach(option=>{
                if(option.value === data){
                    option.selected = true;
                }
            });
        } catch(err) {
            console.log(err);
        }
    }
    fetchMobileCode(URL);

    // Country Dropdown Auto Select Script
    let cookie = document.cookie,
    arrOfCookieVal;
    arrOfCookieVal = cookie.split(";");
    arrOfCookieVal.forEach(item=>{
        var item = item.toString();
        if(item.includes("country")) {
            let options = document.querySelectorAll('.countryfield option'),
            countryName = item.split("=").slice(-1).toString();
            options.forEach(option=>{
                if(option.value === countryName){
                    option.selected = true;
                }
            });
        }
    });

    let myCookie = document.cookie,
    arrOfMyCookieVal = myCookie.split(";");
    arrOfMyCookieVal.forEach(item=>{
        var item = item.toString(),
        postalCode = (item.includes("postal") ? item.split("=")[1] : "");
        if(postalCode) {
            ( jQuery(".postal-code") ? jQuery(".postal-code").val(postalCode.trim()) : "" );
            ( jQuery(".postal-code") && jQuery(".postal-code").val(postalCode.trim()) ? jQuery(".postal-code").find("label").css("display", "none") : "" );
        }
    });
    
    if(window.location.href.includes("#freshteam")) {
        window.addEventListener("load", function(event){
            event.preventDefault();
            jQuery('html, body').animate({
                scrollTop:  jQuery('#freshteam').offset().top - 120
            }, 0);
        }, 500);
    }

    if(window.location.href.includes("#freshsales")) {
        window.addEventListener("load", function(event){
            event.preventDefault();
            jQuery('html, body').animate({
                scrollTop:  jQuery('#freshsales').offset().top - 120
            }, 0);
        }, 500);
    }

    if(window.location.href.includes("#freshservice")) {
        window.addEventListener("load", function(event){
            event.preventDefault();
            jQuery('html, body').animate({
                scrollTop:  jQuery('#freshservice').offset().top - 120
            }, 0);
        }, 500);
    }

    // Qlik Page Specific Script 
    const closeTabs = document.querySelectorAll(".qlik-tabs .close-tab"),
    tabTitles = document.querySelectorAll(".qlik-tabs .eael-tab-top-icon li");
    closeTabs.forEach((closeTab, index1)=>{
        closeTab.addEventListener("click", function(e){
            e.target.parentElement.parentElement.classList.replace("active", "inactive");
            tabTitles.forEach((tabTitle, index2)=>{
                if(index1 == index2) {
                    tabTitle.classList.replace("active", "inactive");
                }
            });
        });
    });

    // Foundational Services & Hybrid Cloud Services
    const foundationServices = document.querySelector('.foundational-services .elementor-widget-container'),
    foundationServicesContent = document.querySelector('.foundational-services-content'),
    foundationalServiceCloseTab = document.querySelector('.foundational-services-content .close_tab'),
    hybridCloudServices = document.querySelector('.hybrid-cloud .elementor-widget-container'),
    hybridCloudServicesContent = document.querySelector('.hybrid-cloud-content'),
    hybridCloudServiceCloseTab = document.querySelector('.hybrid-cloud-content .close_tab');
    if(foundationServices) {
        foundationServices.addEventListener("click", function(){
            foundationServicesContent.classList.add("active");
        });
    }
    if(foundationalServiceCloseTab) {
        foundationalServiceCloseTab.addEventListener("click", function(){
            foundationServicesContent.classList.remove("active");
        });
    }
    const universalConnect = document.querySelector(".universal-connect-btn");
    if(universalConnect) {
        universalConnect.addEventListener("click", function(e){
            e.preventDefault();
        });
    }

    if(hybridCloudServices) {
        hybridCloudServices.addEventListener('click', function(){
            hybridCloudServicesContent.classList.add("active");
        });
    }

    if(hybridCloudServiceCloseTab) {
        hybridCloudServiceCloseTab.addEventListener("click", function(){
            hybridCloudServicesContent.classList.remove("active");
        });
    }    

    // Disable cut, copy and paste
    const blockedAction = e => {
        e.preventDefault();
    }
    const disabledKeys = ["c", "x", "v", "insert", ""];
    document.addEventListener("keydown", e =>{
        if((e.ctrlKey && disabledKeys.includes(e.key)) || (e.shiftKey && disabledKeys.includes(e.key)) || e.key === "F12") {
            blockedAction(e);
        }
    });
    document.addEventListener("paste", e=>{
        blockedAction(e);
    });
}) ;
