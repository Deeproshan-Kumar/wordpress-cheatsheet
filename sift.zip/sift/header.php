<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="http://gmpg.org/xfn/11" />
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />        
    <?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div class="navbar">
    <!-- Icon for Responsive Menu  -->
    <div id="hamburger" class="hamburger">
        <span class="bars"></span>
        <span class="bars"></span>
        <span class="bars"></span>
    </div>
    <div class="navbar-wrapper">
        <div class="logo">
        <?php
        if(has_custom_logo() ):
            the_custom_logo();
        else : ?>
            <a href="<?php echo get_home_url('/') ?>"><?php bloginfo('name') ?></a>
        <?php endif; ?>
        </div>
        <div class="navigation">
            <?php
                wp_nav_menu([
                    'theme_location' => 'primary_menu',
                    'menu_id' => 'navigation'
                ]);
            ?>
        </div>
    </div>
</div>